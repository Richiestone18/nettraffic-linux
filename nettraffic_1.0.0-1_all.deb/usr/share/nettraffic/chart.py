#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Ventana de gráfica flotante: GTK3 + cairo. Área/columnas/líneas, rect o velocímetro."""
import math

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
gi.require_version('PangoCairo', '1.0')
from gi.repository import Gtk, Gdk, GLib
import cairo

from .core import (fmt_amount, parse_amount, hex_to_rgba, nice_ceil,
                   quota_period_progress, other_window_fullscreen)

UP_ARROW = "↑"
DOWN_ARROW = "↓"

_ZONE_CURSORS = None


def _zone_cursor_types():
    """Mapa ventana-borde → cursor de redimensión (lazy: requiere Gdk ya inicializado)."""
    global _ZONE_CURSORS
    if _ZONE_CURSORS is None:
        _ZONE_CURSORS = {
            Gdk.WindowEdge.NORTH_WEST: Gdk.CursorType.TOP_LEFT_CORNER,
            Gdk.WindowEdge.NORTH_EAST: Gdk.CursorType.TOP_RIGHT_CORNER,
            Gdk.WindowEdge.SOUTH_WEST: Gdk.CursorType.BOTTOM_LEFT_CORNER,
            Gdk.WindowEdge.SOUTH_EAST: Gdk.CursorType.BOTTOM_RIGHT_CORNER,
            Gdk.WindowEdge.NORTH: Gdk.CursorType.TOP_SIDE,
            Gdk.WindowEdge.SOUTH: Gdk.CursorType.BOTTOM_SIDE,
            Gdk.WindowEdge.WEST: Gdk.CursorType.LEFT_SIDE,
            Gdk.WindowEdge.EAST: Gdk.CursorType.RIGHT_SIDE,
        }
    return _ZONE_CURSORS


class ChartWindow(Gtk.Window):
    def __init__(self, app):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.app = app
        self.cfg = app.cfg
        self.shape = app.x11shape
        self._pointer_inside = False
        self._hidden_by_fullscreen = False
        self._last_transparent = None

        self.set_title("NetTraffic")
        self.set_app_paintable(True)
        self.set_border_width(0)
        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)

        self.da = Gtk.DrawingArea()
        self.add(self.da)
        self.da.connect("draw", self.on_draw)
        # los eventos los recibe el DrawingArea (cubre toda la ventana);
        # conectar a la toplevel no sirve: su GDK window queda debajo
        self.da.add_events(Gdk.EventMask.BUTTON_PRESS_MASK
                           | Gdk.EventMask.BUTTON_RELEASE_MASK
                           | Gdk.EventMask.POINTER_MOTION_MASK
                           | Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.da.connect("button-press-event", self.on_button)
        self.da.connect("button-release-event", self.on_release)
        self.da.connect("motion-notify-event", self.on_motion)
        self.da.connect("leave-notify-event", self.on_leave)
        self.connect("configure-event", self.on_configure)
        self.connect("delete-event", self.on_delete)
        self._resize_zone = None
        self._resize_drag = None   # (zone, x0, y0, w0, h0, px0, py0)

        self.apply_config(first=True)
        self.show_all()
        # Compiz pisa posición y opacidad al mapear: re-aplicar tras el show
        loc = self.cfg["general"]["location"]
        self.move(int(loc.get("x", 60)), int(loc.get("y", 40)))
        self._set_wm_opacity(self._target_opacity())

        GLib.timeout_add(self._redraw_interval_ms(), self._tick_redraw)
        GLib.timeout_add(250, self._tick_pointer)
        GLib.timeout_add(3000, self._tick_fullscreen)

    # ── configuración ──
    def _redraw_interval_ms(self):
        return max(100, min(int(self.cfg["general"]["frequency_ms"]), 1000))

    def _target_opacity(self):
        tr = max(0, min(90, int(self.cfg["plot"]["transparency"])))
        return 1.0 - tr / 100.0

    def _set_wm_opacity(self, opacity):
        """Fija _NET_WM_WINDOW_OPACITY vía Xlib crudo: GDK get_atom no sirve
        para propiedades del WM y Compiz ignora set_opacity cerca del map."""
        try:
            win = self.get_window()
            if win is None:
                return
            import ctypes
            lib = ctypes.CDLL("libX11.so.6")
            lib.XOpenDisplay.restype = ctypes.c_void_p
            lib.XInternAtom.restype = ctypes.c_ulong
            lib.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
            lib.XChangeProperty.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong,
                                             ctypes.c_ulong, ctypes.c_int, ctypes.c_int,
                                             ctypes.c_void_p, ctypes.c_int]
            disp = lib.XOpenDisplay(None)
            if not disp:
                return
            atom = lib.XInternAtom(disp, b"_NET_WM_WINDOW_OPACITY", False)
            CARDINAL, PROP_MODE_REPLACE = 6, 0
            val = ctypes.c_uint32(int(max(0.01, min(1.0, opacity)) * 0xFFFFFFFF))
            lib.XChangeProperty(disp, ctypes.c_ulong(win.get_xid()), atom,
                                CARDINAL, 32, PROP_MODE_REPLACE,
                                ctypes.byref(val), 1)
            lib.XFlush(disp)
        except Exception:
            pass

    def apply_config(self, first=False):
        p = self.cfg["plot"]
        g = self.cfg["general"]
        loc = g["location"]
        self.set_decorated(bool(p["window_frame"]))
        self.set_keep_above(bool(g["on_top"]))
        self.set_skip_taskbar_hint(not bool(p["window_frame"]))
        self.set_skip_pager_hint(not bool(p["window_frame"]))
        self._set_wm_opacity(self._target_opacity())
        w = max(80, int(loc.get("width", 320)))
        h = max(60, int(loc.get("height", 120)))
        self.resize(w, h)
        self.move(int(loc.get("x", 60)), int(loc.get("y", 40)))
        win = self.get_window()
        if win is not None:
            self.shape.set_click_through(win.get_xid(), bool(g["click_through"]))
        self.da.queue_draw()

    def restore_state(self):
        if self.cfg["general"]["window_restore"] == 0:
            self.hide()

    # ── eventos ──
    def on_configure(self, widget, event):
        x, y = self.get_position()
        w, h = self.get_size()
        self.cfg["general"]["location"] = {"x": x, "y": y, "width": w, "height": h}
        return False

    def on_delete(self, widget, event):
        if self.cfg["general"]["close_to_tray"]:
            self.hide()
            return True
        self.app.quit()
        return False

    def on_button(self, widget, event):
        if event.button == 3 and not self.cfg["general"]["click_through"]:
            self.app.menu.popup_at_pointer(event)
            return True
        if event.button == 1 and not self.cfg["plot"]["window_frame"]:
            # zona calculada AQUÍ (no dependemos del motion previo)
            zone = self._zone_at(event.x, event.y,
                                 widget.get_allocated_width(), widget.get_allocated_height())
            if zone is not None:
                # redimensión manual (independiente del WM)
                w, h = self.get_size()
                px, py = self.get_position()
                self._resize_drag = (zone, int(event.x_root), int(event.y_root),
                                     w, h, px, py)
                return True
            try:
                self.begin_move_drag(event.button, int(event.x_root), int(event.y_root), event.time)
            except Exception:
                pass
            return True
        return False

    def on_release(self, widget, event):
        if event.button == 1 and self._resize_drag is not None:
            self._resize_drag = None
            # persistir tamaño en config
            x, y = self.get_position()
            w, h = self.get_size()
            self.cfg["general"]["location"] = {"x": x, "y": y, "width": w, "height": h}
        return False

    MIN_W, MIN_H = 80, 60

    def _apply_resize(self, zone, dx, dy, w0, h0, px0, py0):
        """Redimensión manual: ajusta tamaño (y posición en bordes N/O)."""
        x, y = px0, py0
        w, h = w0, h0
        if zone in (Gdk.WindowEdge.EAST, Gdk.WindowEdge.SOUTH_EAST, Gdk.WindowEdge.NORTH_EAST):
            w = max(self.MIN_W, w0 + dx)
        if zone in (Gdk.WindowEdge.WEST, Gdk.WindowEdge.SOUTH_WEST, Gdk.WindowEdge.NORTH_WEST):
            w = max(self.MIN_W, w0 - dx)
            x = px0 + (w0 - w)
        if zone in (Gdk.WindowEdge.SOUTH, Gdk.WindowEdge.SOUTH_EAST, Gdk.WindowEdge.SOUTH_WEST):
            h = max(self.MIN_H, h0 + dy)
        if zone in (Gdk.WindowEdge.NORTH, Gdk.WindowEdge.NORTH_EAST, Gdk.WindowEdge.NORTH_WEST):
            h = max(self.MIN_H, h0 - dy)
            y = py0 + (h0 - h)
        self.resize(w, h)
        self.move(x, y)

    # ── redimensión por bordes/esquinas (ventana sin marco) ──
    EDGE_PX = 14

    def on_motion(self, widget, event):
        # arrastre de redimensión en curso
        if self._resize_drag is not None:
            zone, x0, y0, w0, h0, px0, py0 = self._resize_drag
            self._apply_resize(zone, int(event.x_root) - x0, int(event.y_root) - y0,
                               w0, h0, px0, py0)
            return False
        zone = self._zone_at(event.x, event.y,
                             widget.get_allocated_width(), widget.get_allocated_height())
        if zone != self._resize_zone:
            self._resize_zone = zone
            win = self.get_window()
            if win is not None:
                if zone is None:
                    win.set_cursor(None)
                else:
                    try:
                        cur = Gdk.Cursor.new_for_display(Gdk.Display.get_default(),
                                                         _zone_cursor_types()[zone])
                        win.set_cursor(cur)
                    except Exception:
                        pass
        return False

    def on_leave(self, widget, event):
        if self._resize_zone is not None:
            self._resize_zone = None
            win = self.get_window()
            if win is not None:
                win.set_cursor(None)
        return False

    def _zone_at(self, x, y, w, h):
        if self.cfg["plot"]["window_frame"]:
            return None
        e = self.EDGE_PX
        west = x < e
        east = x > w - e
        north = y < e
        south = y > h - e
        if north and west:
            return Gdk.WindowEdge.NORTH_WEST
        if north and east:
            return Gdk.WindowEdge.NORTH_EAST
        if south and west:
            return Gdk.WindowEdge.SOUTH_WEST
        if south and east:
            return Gdk.WindowEdge.SOUTH_EAST
        if north:
            return Gdk.WindowEdge.NORTH
        if south:
            return Gdk.WindowEdge.SOUTH
        if west:
            return Gdk.WindowEdge.WEST
        if east:
            return Gdk.WindowEdge.EAST
        return None

    # ── ticks ──
    def _tick_redraw(self):
        self.da.queue_draw()
        return True

    def _tick_pointer(self):
        try:
            disp = Gdk.Display.get_default()
            ptr = disp.get_default_seat().get_pointer()
            if ptr is not None:
                _, px, py = ptr.get_position()
                wx, wy = self.get_position()
                w, h = self.get_size()
                inside = wx <= px < wx + w and wy <= py < wy + h
                if inside != self._pointer_inside:
                    self._pointer_inside = inside
                    if self.cfg["general"]["hide_under_pointer"]:
                        self._set_wm_opacity(0.0 if inside else self._target_opacity())
                if not self.cfg["general"]["hide_under_pointer"] and self._pointer_inside is False:
                    # restaurar si quedó en 0 por algún motivo
                    pass
        except Exception:
            pass
        return True

    def _tick_fullscreen(self):
        g = self.cfg["general"]
        if not g["hide_when_fullscreen"]:
            if self._hidden_by_fullscreen:
                self._hidden_by_fullscreen = False
                self.show()
            return True
        fs = other_window_fullscreen()
        if fs and not self._hidden_by_fullscreen:
            self._hidden_by_fullscreen = True
            self.hide()
        elif not fs and self._hidden_by_fullscreen:
            self._hidden_by_fullscreen = False
            self.show()
        return True

    # ── dibujo ──
    def _theme_colors(self):
        p = self.cfg["plot"]
        return p["colors"].get(p["theme"], p["colors"]["dark"])

    def _fmt_rate(self, n):
        return fmt_amount(n, self.cfg["general"]["unit_speed"], per_second=True)

    def on_draw(self, da, cr):
        p = self.cfg["plot"]
        theme = self._theme_colors()
        w = da.get_allocated_width()
        h = da.get_allocated_height()
        if w < 20 or h < 20:
            return False

        # fondo
        cr.set_source_rgba(*hex_to_rgba(theme["back"]))
        if p["window_frame"]:
            cr.rectangle(0, 0, w, h)
        else:
            self._round_rect(cr, 0, 0, w, h, 6)
        cr.fill()

        title_h = 17 if (p["title_bar"] and not p["window_frame"]) else 0
        if title_h:
            self._draw_title_bar(cr, w, title_h, theme)

        dl, ul = self.app.sampler.get_rates()
        points = self.app.sampler.get_points(max(2, int(p["points_count"])))

        top = title_h + (4 if title_h else 2)
        pad_left = 4 if p["hide_y_labels"] else 40
        chart_w = max(10, w - pad_left - 4)
        chart_h = max(10, h - top - 14)

        if p["chart_shape"] == "pie":
            self._draw_pie(cr, 2, top - 2, w - 4, h - top - 2, dl, ul, points, theme)
        else:
            self._draw_rectangle_chart(cr, pad_left, top, chart_w, chart_h, dl, ul, points, theme)
        return False

    def _round_rect(self, cr, x, y, w, h, r):
        r = max(0.0, min(r, w / 2.0, h / 2.0))
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
        cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
        cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
        cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()

    def _draw_title_bar(self, cr, w, hgt, theme):
        cr.set_source_rgba(*hex_to_rgba(theme["font"], 0.07))
        self._round_rect(cr, 0, 0, w, hgt, 6)
        cr.fill()
        cr.set_source_rgba(*hex_to_rgba(theme["axis"], 0.5))
        cr.set_line_width(0.7)
        cr.move_to(2, hgt)
        cr.line_to(w - 2, hgt)
        cr.stroke()
        cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(9)
        p = self.cfg["plot"]
        dl, ul = self.app.sampler.get_rates()

        # construir elementos visibles
        elems = []
        if p.get("show_dl", True):
            elems.append((DOWN_ARROW, self._fmt_rate(dl), theme["download"]))
        if p.get("show_ul", True):
            elems.append((UP_ARROW, self._fmt_rate(ul), theme["upload"]))
        if p.get("show_total", False):
            elems.append(("Σ", self._fmt_rate(dl + ul), theme["total"]))
        if self.cfg["quota"]["enabled"] and p.get("show_quota", True):
            q = self.cfg["quota"]
            limit = parse_amount(q["limit"]["value"], q["limit"]["prefix"], q["limit"]["kind"])
            used = q.get("used_bytes", 0)
            pct = (used / limit * 100.0) if limit > 0 else 0.0
            col = theme["download"] if pct < 80 else (theme["activity"] if pct < 100 else theme["upload"])
            elems.append(("", "%.0f%%" % pct, col))

        # medir ancho total y dibujar centrado
        GAP = 14
        total_w = 0
        widths = []
        for arrow, txt, _ in elems:
            tw = cr.text_extents(arrow + " " + txt).width
            widths.append(tw)
            total_w += tw
        total_w += GAP * max(0, len(elems) - 1)

        x = max(4.0, (w - total_w) / 2.0)
        for i, (arrow, txt, color) in enumerate(elems):
            label = (arrow + " " + txt).strip()
            cr.set_source_rgba(*hex_to_rgba(color))
            cr.move_to(x, 12)
            cr.show_text(label)
            x += widths[i] + GAP

    def _scale_max(self, dl, ul, points):
        p = self.cfg["plot"]
        if p["scale_y"] == "manual":
            m = parse_amount(p["scale_max"]["value"], p["scale_max"]["prefix"], p["scale_max"]["kind"])
            return max(1.0, m)
        mx = max(dl, ul)
        if p.get("show_total", False):
            mx = max(mx, dl + ul)
        n = int(p["points_count"])
        for _, d, u in points[-n:]:
            mx = max(mx, d + u if p.get("show_total", False) else max(d, u))
        return nice_ceil(mx * 1.05 + 1e-9)

    def _draw_rectangle_chart(self, cr, x0, y0, pw, ph, dl, ul, points, theme):
        p = self.cfg["plot"]
        smax = self._scale_max(dl, ul, points)

        # rejilla + etiquetas Y
        cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        cr.set_font_size(7)
        for i in range(5):
            frac = i / 4.0
            y = y0 + ph - ph * frac
            cr.set_source_rgba(*hex_to_rgba(theme["axis"], 0.4))
            cr.set_line_width(0.5)
            cr.move_to(x0, y)
            cr.line_to(x0 + pw, y)
            cr.stroke()
            if not p["hide_y_labels"]:
                lbl = fmt_amount(smax * frac, self.cfg["general"]["unit_speed"], per_second=True)
                cr.set_source_rgba(*hex_to_rgba(theme["font"], 0.75))
                cr.move_to(max(1, x0 - cr.text_extents(lbl).width - 3), y + 3)
                cr.show_text(lbl)
        # línea base
        cr.set_source_rgba(*hex_to_rgba(theme["axis"], 0.8))
        cr.set_line_width(0.8)
        cr.move_to(x0, y0 + ph)
        cr.line_to(x0 + pw, y0 + ph)
        cr.stroke()

        nmax = max(2, int(p["points_count"]))
        data = points[-nmax:]
        if len(data) < 2:
            return
        slot = pw / float(nmax)
        bw = max(1.0, min(slot * 0.8, max(1.5, float(p["point_width"]))))

        def yval(v):
            return y0 + ph - min(1.0, v / smax) * ph

        def stroke_series(vals, color, filled):
            if p["chart_type"] == "column":
                cr.set_source_rgba(*hex_to_rgba(color, 0.9))
                for i, v in enumerate(vals):
                    cx = x0 + slot * i + (slot - bw) / 2.0
                    cr.rectangle(cx, yval(v), bw, y0 + ph - yval(v))
                cr.fill()
            elif p["chart_type"] == "area":
                cr.set_source_rgba(*hex_to_rgba(color, 0.55))
                cr.move_to(x0, y0 + ph)
                for i, v in enumerate(vals):
                    cr.line_to(x0 + slot * i + bw / 2.0, yval(v))
                cr.line_to(x0 + slot * (len(vals) - 1) + bw / 2.0, y0 + ph)
                cr.close_path()
                cr.fill()
                cr.set_source_rgba(*hex_to_rgba(color, 1.0))
                cr.set_line_width(1.0)
                cr.move_to(x0 + slot * 0 + bw / 2.0, yval(vals[0]))
                for i, v in enumerate(vals):
                    cr.line_to(x0 + slot * i + bw / 2.0, yval(v))
                cr.stroke()
            else:  # line
                cr.set_source_rgba(*hex_to_rgba(color, 1.0))
                cr.set_line_width(1.2)
                cr.move_to(x0, yval(vals[0]))
                for i, v in enumerate(vals):
                    cr.line_to(x0 + slot * i + bw / 2.0, yval(v))
                cr.stroke()

        if p.get("show_total", False):
            stroke_series([d + u for (_, d, u) in data], theme["total"], True)
        if p.get("show_dl", True):
            stroke_series([d for (_, d, _) in data], theme["download"], True)
        if p.get("show_ul", True):
            stroke_series([u for (_, _, u) in data], theme["upload"], True)

    def _draw_pie(self, cr, x0, y0, pw, ph, dl, ul, points, theme):
        """Velocímetro: arco de 270°, la serie más alta traza el contorno."""
        p = self.cfg["plot"]
        smax = self._scale_max(dl, ul, points)
        cx = x0 + pw / 2.0
        cy = y0 + ph / 2.0 + ph * 0.08
        r = max(6.0, min(pw, ph * 1.6) / 2.2)
        a0 = 0.75 * math.pi   # 135°
        a1 = 2.25 * math.pi   # 405° (=45°)

        # pista
        cr.set_source_rgba(*hex_to_rgba(theme["axis"], 0.35))
        cr.set_line_width(3.0)
        cr.new_sub_path()
        cr.arc(cx, cy, r, a0, a1)
        cr.stroke()
        # marcas
        cr.set_font_size(7)
        for i in range(5):
            frac = i / 4.0
            ang = a0 + (a1 - a0) * frac
            mx = cx + math.cos(ang) * (r + 5)
            my = cy + math.sin(ang) * (r + 5)
            cr.set_source_rgba(*hex_to_rgba(theme["font"], 0.6))
            lbl = fmt_amount(smax * frac, self.cfg["general"]["unit_speed"], per_second=True)
            cr.move_to(mx - cr.text_extents(lbl).width / 2, my + 3)
            cr.show_text(lbl)

        nmax = max(2, int(p["points_count"]))
        data = points[-nmax:]
        if len(data) < 2:
            return

        def draw_gauge(vals, color):
            cr.set_source_rgba(*hex_to_rgba(color, 0.95))
            cr.set_line_width(2.2)
            cr.new_sub_path()
            cr.move_to(cx + math.cos(a0) * r, cy + math.sin(a0) * r)
            for i, v in enumerate(vals):
                frac = min(1.0, v / smax)
                ang = a0 + (a1 - a0) * frac
                cr.line_to(cx + math.cos(ang) * r, cy + math.sin(ang) * r)
            cr.stroke()

        if p.get("show_dl", True):
            draw_gauge([d for (_, d, _) in data], theme["download"])
        if p.get("show_ul", True):
            draw_gauge([u for (_, _, u) in data], theme["upload"])
        if p.get("show_total", False):
            draw_gauge([d + u for (_, d, u) in data], theme["total"])

        # lectura actual en el centro
        cr.set_source_rgba(*hex_to_rgba(theme["font"], 0.9))
        cr.set_font_size(max(9, min(14, r * 0.32)))
        txt = self._fmt_rate(dl + ul)
        cr.move_to(cx - cr.text_extents(txt).width / 2, cy + r * 0.1)
        cr.show_text(txt)
