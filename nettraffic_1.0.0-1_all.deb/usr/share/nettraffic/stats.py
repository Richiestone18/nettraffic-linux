#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Ventana de Estadísticas: tabla por días del mes + sesión + cuota."""
import os
from datetime import datetime, timedelta

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

from .core import fmt_amount, parse_amount, quota_period_bounds


class StatsWindow(Gtk.Window):
    def __init__(self, app):
        super().__init__(title="NetTraffic")
        self.app = app
        self.cfg = app.cfg
        self.tr = app.tr
        self.set_default_size(560, 420)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        vb.set_border_width(8)
        self.add(vb)

        nb = Gtk.Notebook()
        vb.pack_start(nb, True, True, 0)
        nb.append_page(self._page_table(), Gtk.Label(label=self.tr("table")))
        nb.append_page(self._page_summary(), Gtk.Label(label=self.tr("session")))

        hb = Gtk.Box(spacing=6, halign=Gtk.Align.END)
        vb.pack_start(hb, False, False, 4)
        b_export = Gtk.Button(label=self.tr("export"))
        b_export.connect("clicked", self.on_export)
        hb.pack_start(b_export, False, False, 0)
        b_clear = Gtk.Button(label=self.tr("clear_data"))
        b_clear.connect("clicked", self.on_clear)
        hb.pack_start(b_clear, False, False, 0)
        b_close = Gtk.Button(label=self.tr("ok"))
        b_close.connect("clicked", lambda *_: self.destroy())
        hb.pack_start(b_close, False, False, 0)

    def _page_table(self):
        sw = Gtk.ScrolledWindow()
        store = Gtk.ListStore(str, str, str, str)
        stats = self.app.sampler.get_month_stats()
        kind = self.cfg["quota"]["limit"]["kind"] if self.cfg["quota"]["enabled"] else "iB"
        days = stats.get("days", {})
        now = datetime.now()
        for dkey in sorted(days, reverse=True):
            rx, tx = days[dkey]
            try:
                d = datetime.strptime("%s-%s" % (stats["month"], dkey), "%Y-%m-%d")
                dlabel = d.strftime("%a %d %b")
            except Exception:
                dlabel = dkey
            store.append([dlabel, fmt_amount(rx, kind), fmt_amount(tx, kind),
                          fmt_amount(rx + tx, kind)])
        tv = Gtk.TreeView(model=store)
        for i, (title, kind_col) in enumerate((
                (self.tr("date"), 0), (self.tr("download"), 0),
                (self.tr("upload"), 0), (self.tr("total"), 0))):
            col = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=i)
            col.set_alignment(0.5 if i == 0 else 1.0)
            tv.append_column(col)
        sw.add(tv)
        return sw

    def _page_summary(self):
        grid = Gtk.Grid(column_spacing=12, row_spacing=6, margin=10)
        rx, tx = self.app.sampler.get_session_totals()
        kind = "iB"

        def add(row, label, val):
            grid.attach(Gtk.Label(label=label, halign=Gtk.Align.START), 0, row, 1, 1)
            grid.attach(Gtk.Label(label=val, halign=Gtk.Align.END), 1, row, 1, 1)

        add(0, self.tr("download"), fmt_amount(rx, kind))
        add(1, self.tr("upload"), fmt_amount(tx, kind))
        add(2, self.tr("total"), fmt_amount(rx + tx, kind))
        dur = datetime.now() - self.app.started_at
        add(3, self.tr("speed") + " " + self.tr("avg").lower(),
            fmt_amount((rx + tx) / max(1.0, dur.total_seconds()), kind, per_second=True))
        # cuota
        if self.cfg["quota"]["enabled"]:
            q = self.cfg["quota"]
            limit = parse_amount(q["limit"]["value"], q["limit"]["prefix"], q["limit"]["kind"])
            used = q.get("used_bytes", 0)
            start, end = quota_period_bounds(self.cfg)
            grid.attach(Gtk.Separator(), 0, 4, 2, 1)
            add(5, self.tr("quota") + " · " + self.tr("used"), fmt_amount(used, q["limit"]["kind"]))
            add(6, self.tr("limit"), fmt_amount(limit, q["limit"]["kind"]))
            add(7, self.tr("left"), fmt_amount(max(0.0, limit - used), q["limit"]["kind"]))
            add(8, self.tr("period_end"), end.strftime("%Y-%m-%d %H:%M"))
        grid.show_all()
        return grid

    def on_export(self, btn):
        dlg = Gtk.FileChooserNative.new(self.tr("export"), self, Gtk.FileChooserAction.SAVE,
                                        None, None)
        dlg.set_current_name("nettraffic-%s.csv" % datetime.now().strftime("%Y%m%d"))
        dlg.set_do_overwrite_confirmation(True)
        if dlg.run() != Gtk.ResponseType.ACCEPT:
            return
        path = dlg.get_filename()
        stats = self.app.sampler.get_month_stats()
        kind = "iB"
        with open(path, "w", encoding="utf-8") as f:
            f.write("date,download_bytes,upload_bytes,total_bytes,download,upload,total\n")
            for dkey in sorted(stats.get("days", {})):
                rx, tx = stats["days"][dkey]
                f.write("%s-%s,%d,%d,%d,%s,%s,%s\n" % (
                    stats["month"], dkey, int(rx), int(tx), int(rx + tx),
                    fmt_amount(rx, kind), fmt_amount(tx, kind), fmt_amount(rx + tx, kind)))
        dlg.destroy()

    def on_clear(self, btn):
        dlg = Gtk.MessageDialog(transient_for=self, modal=True,
                                message_type=Gtk.MessageType.QUESTION,
                                buttons=Gtk.ButtonsType.YES_NO,
                                text=self.tr("ask_clear"))
        if dlg.run() == Gtk.ResponseType.YES:
            self.app.sampler.clear_stats()
        dlg.destroy()
