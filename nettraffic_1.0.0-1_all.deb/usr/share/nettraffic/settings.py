#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Ventana de Ajustes: pestañas General / Gráfica / Cuota (como el original)."""
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from .core import read_interfaces, is_loopback, save_settings

L = "general", "chart", "quota"


class SettingsWindow(Gtk.Window):
    def __init__(self, app):
        super().__init__(title="NetTraffic")
        self.app = app
        self.cfg = app.cfg
        self.tr = app.tr
        self.set_default_size(460, 520)
        self.set_transient_for(app.win if app.win else None)

        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        vb.set_border_width(8)
        self.add(vb)

        self.nb = Gtk.Notebook()
        vb.pack_start(self.nb, True, True, 0)

        self.nb.append_page(self._page_general(), Gtk.Label(label=self.tr("general")))
        self.nb.append_page(self._page_chart(), Gtk.Label(label=self.tr("chart")))
        self.nb.append_page(self._page_quota(), Gtk.Label(label=self.tr("quota")))

        # botones
        hb = Gtk.Box(spacing=6, halign=Gtk.Align.END)
        vb.pack_start(hb, False, False, 4)
        b_reset = Gtk.Button(label=self.tr("reset"))
        b_reset.connect("clicked", self.on_reset)
        hb.pack_start(b_reset, False, False, 0)
        b_cancel = Gtk.Button(label=self.tr("cancel"))
        b_cancel.connect("clicked", lambda *_: self.destroy())
        hb.pack_start(b_cancel, False, False, 0)
        b_apply = Gtk.Button(label=self.tr("apply"))
        b_apply.connect("clicked", self.on_apply)
        hb.pack_start(b_apply, False, False, 0)
        b_ok = Gtk.Button(label=self.tr("ok"))
        b_ok.connect("clicked", self.on_ok)
        hb.pack_start(b_ok, False, False, 0)

    # ── helpers ──
    def _frame(self, title):
        f = Gtk.Frame(label=title)
        f.set_border_width(4)
        g = Gtk.Grid(column_spacing=8, row_spacing=4, margin=6)
        f.add(g)
        return f, g

    def _add_row(self, grid, row, label, widget):
        grid.attach(Gtk.Label(label=label, halign=Gtk.Align.START), 0, row, 1, 1)
        grid.attach(widget, 1, row, 1, 1)
        return row + 1

    def _check(self, key_path, section):
        """Checkbox bindeado a cfg[section][key]."""
        cb = Gtk.CheckButton()
        obj = self.cfg[section]
        for k in key_path[:-1]:
            obj = obj[k]
        cb.set_active(bool(obj[key_path[-1]]))
        cb.connect("toggled", self._mk_setter(section, key_path))
        return cb

    def _mk_setter(self, section, key_path):
        def setter(w):
            obj = self.cfg[section]
            for k in key_path[:-1]:
                obj = obj[k]
            obj[key_path[-1]] = w.get_active()
        return setter

    # ── pestaña General ──
    def _page_general(self):
        g = self.cfg["general"]
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        sw.add(vb)

        # idioma
        f, gr = self._frame(self.tr("language"))
        cb_lang = Gtk.ComboBoxText()
        cb_lang.append_text("Español")
        cb_lang.append_text("English")
        cb_lang.set_active(0 if g["language"] == "es" else 1)
        cb_lang.connect("changed", lambda w: self.cfg["general"].__setitem__(
            "language", "es" if w.get_active() == 0 else "en"))
        self._add_row(gr, 0, self.tr("language"), cb_lang)
        vb.pack_start(f, False, False, 0)

        # comportamiento
        f, gr = self._frame(self.tr("behavior"))
        r = 0
        for key, label in (("on_top", "on_top"), ("click_through", "click_through"),
                            ("hide_under_pointer", "hide_under_pointer"),
                            ("hide_when_fullscreen", "hide_fullscreen"),
                            ("close_to_tray", "close_tray"),
                            ("start_with_system", "start_system")):
            gr.attach(self._check((key,), "general"), 0, r, 1, 1)
            gr.attach(Gtk.Label(label=self.tr(label), halign=Gtk.Align.START), 1, r, 1, 1)
            r += 1
        vb.pack_start(f, False, False, 0)

        # intervalo
        f, gr = self._frame(self.tr("frequency"))
        adj = Gtk.Adjustment(value=g["frequency_ms"], lower=100, upper=60000, step_increment=100)
        sp = Gtk.SpinButton(adjustment=adj)
        sp.set_value(g["frequency_ms"])
        sp.connect("value-changed", lambda w: self.cfg["general"].__setitem__("frequency_ms", int(w.get_value())))
        self._add_row(gr, 0, self.tr("frequency"), sp)
        vb.pack_start(f, False, False, 0)

        # interfaces
        f, gr = self._frame(self.tr("interfaces"))
        r = 0
        rb_all = Gtk.RadioButton.new_with_label_from_widget(None, self.tr("if_all"))
        rb_sel = Gtk.RadioButton.new_with_label_from_widget(rb_all, self.tr("if_selected"))
        if g["interfaces_mode"] == "all":
            rb_all.set_active(True)
        else:
            rb_sel.set_active(True)

        def mode_toggled(w):
            if rb_all.get_active():
                self.cfg["general"]["interfaces_mode"] = "all"
            else:
                self.cfg["general"]["interfaces_mode"] = "selected"

        rb_all.connect("toggled", mode_toggled)
        rb_sel.connect("toggled", mode_toggled)
        gr.attach(rb_all, 0, r, 1, 1)
        gr.attach(Gtk.Label(), 1, r, 1, 1)
        r += 1
        gr.attach(rb_sel, 0, r, 1, 1)
        r += 1
        gr.attach(self._check(("exclude_loopback",), "general"), 0, r, 1, 1)
        gr.attach(Gtk.Label(label=self.tr("exclude_lo"), halign=Gtk.Align.START), 1, r, 1, 1)
        r += 1
        # lista de interfaces (solo activa con "selected")
        self._if_store = Gtk.ListStore(bool, str)
        avail = read_interfaces()
        selected = set(g["selected_interfaces"])
        for name in sorted(avail):
            self._if_store.append([name in selected, name])
        tv = Gtk.TreeView(model=self._if_store)
        rend = Gtk.CellRendererToggle()
        rend.set_property("activatable", True)
        rend.connect("toggled", self._if_toggled)
        col_t = Gtk.TreeViewColumn("", rend, active=0)
        tv.append_column(col_t)
        col_n = Gtk.TreeViewColumn(self.tr("interfaces"), Gtk.CellRendererText(), text=1)
        tv.append_column(col_n)
        tv.set_headers_visible(False)
        tv.set_size_request(-1, 90)
        sw_if = Gtk.ScrolledWindow()
        sw_if.add(tv)
        gr.attach(sw_if, 0, r, 2, 1)
        vb.pack_start(f, False, False, 0)

        # unidades
        f, gr = self._frame(self.tr("units"))
        cb_u = Gtk.ComboBoxText()
        for label, val in (("b", "b"), ("ib", "ib"), ("B", "B"), ("iB", "iB")):
            cb_u.append_text(val)
        cb_u.set_active(["b", "ib", "B", "iB"].index(g["unit_speed"]))
        cb_u.connect("changed", lambda w: self.cfg["general"].__setitem__(
            "unit_speed", w.get_active_text()))
        self._add_row(gr, 0, self.tr("data_rate"), cb_u)
        vb.pack_start(f, False, False, 0)

        return sw

    def _if_toggled(self, widget, path):
        self._if_store[path][0] = not self._if_store[path][0]
        self.cfg["general"]["selected_interfaces"] = [
            row[1] for row in self._if_store if row[0]]

    # ── pestaña Gráfica ──
    def _page_chart(self):
        p = self.cfg["plot"]
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        sw.add(vb)

        # tema
        f, gr = self._frame(self.tr("theme"))
        cb_theme = Gtk.ComboBoxText()
        cb_theme.append_text(self.tr("dark"))
        cb_theme.append_text(self.tr("light"))
        cb_theme.set_active(0 if p["theme"] == "dark" else 1)

        def theme_changed(w):
            p["theme"] = "dark" if w.get_active() == 0 else "light"

        cb_theme.connect("changed", theme_changed)
        self._add_row(gr, 0, self.tr("theme"), cb_theme)
        vb.pack_start(f, False, False, 0)

        # tipo y forma
        f, gr = self._frame(self.tr("type"))
        r = 0
        cb_type = Gtk.ComboBoxText()
        for label in ("area", "column", "line"):
            cb_type.append_text(self.tr(label))
        cb_type.set_active(["area", "column", "line"].index(p["chart_type"]))
        cb_type.connect("changed", lambda w: p.__setitem__(
            "chart_type", ["area", "column", "line"][w.get_active()]))
        r = self._add_row(gr, r, self.tr("type"), cb_type)
        cb_shape = Gtk.ComboBoxText()
        cb_shape.append_text(self.tr("rectangle"))
        cb_shape.append_text(self.tr("pie"))
        cb_shape.set_active(0 if p["chart_shape"] == "rectangle" else 1)
        cb_shape.connect("changed", lambda w: p.__setitem__(
            "chart_shape", "rectangle" if w.get_active() == 0 else "pie"))
        r = self._add_row(gr, r, self.tr("shape"), cb_shape)
        vb.pack_start(f, False, False, 0)

        # datos
        f, gr = self._frame(self.tr("points"))
        r = 0
        for key, label, lo, hi, step in (("points_count", "points", 10, 600, 1),
                                          ("point_width", "point_width", 1, 20, 1),
                                          ("points_buffer", "buffer", 60, 3600, 10)):
            adj = Gtk.Adjustment(value=p[key], lower=lo, upper=hi, step_increment=step)
            sp = Gtk.SpinButton(adjustment=adj)
            sp.set_value(p[key])
            k = key
            sp.connect("value-changed", lambda w, k=k: p.__setitem__(k, int(w.get_value())))
            r = self._add_row(gr, r, self.tr(label), sp)
        vb.pack_start(f, False, False, 0)

        # escala Y
        f, gr = self._frame(self.tr("scale"))
        rb_auto = Gtk.RadioButton.new_with_label_from_widget(None, self.tr("auto"))
        rb_man = Gtk.RadioButton.new_with_label_from_widget(rb_auto, self.tr("manual"))
        if p["scale_y"] == "auto":
            rb_auto.set_active(True)
        else:
            rb_man.set_active(True)
        rb_auto.connect("toggled", lambda w: p.__setitem__("scale_y", "auto") if w.get_active() else None)
        rb_man.connect("toggled", lambda w: p.__setitem__("scale_y", "manual") if w.get_active() else None)
        self._add_row(gr, 0, self.tr("scale"), rb_auto)
        gr.attach(rb_man, 1, 1, 1, 1)
        adj = Gtk.Adjustment(value=float(p["scale_max"]["value"]), lower=1, upper=1024, step_increment=1)
        sp_max = Gtk.SpinButton(adjustment=adj)
        sp_max.set_sensitive(p["scale_y"] == "manual")
        rb_man.connect("toggled", lambda w: sp_max.set_sensitive(w.get_active()))
        sp_max.connect("value-changed", lambda w: p["scale_max"].__setitem__("value", w.get_value()))
        cb_prefix = Gtk.ComboBoxText()
        for pre in ("", "k", "M", "G", "T"):
            cb_prefix.append_text(pre if pre else "—")
        cur = p["scale_max"]["prefix"]
        cb_prefix.set_active(["", "k", "M", "G", "T"].index(cur))
        cb_prefix.connect("changed", lambda w: p["scale_max"].__setitem__(
            "prefix", ["", "k", "M", "G", "T"][w.get_active()]))
        hb = Gtk.Box(spacing=4)
        hb.pack_start(sp_max, False, False, 0)
        hb.pack_start(cb_prefix, False, False, 0)
        gr.attach(hb, 1, 2, 1, 1)
        vb.pack_start(f, False, False, 0)

        # componentes
        f, gr = self._frame(self.tr("elements"))
        r = 0
        for key, label in (("title_bar", "title_bar"), ("show_dl", "show_dl"), ("show_ul", "show_ul"),
                            ("show_total", "show_total"), ("show_quota", "show_quota"),
                            ("hide_y_labels", "hide_labels"), ("window_frame", "window_mode")):
            gr.attach(self._check((key,), "plot"), 0, r, 1, 1)
            gr.attach(Gtk.Label(label=self.tr(label), halign=Gtk.Align.START), 1, r, 1, 1)
            r += 1
        vb.pack_start(f, False, False, 0)

        # transparencia
        f, gr = self._frame(self.tr("transparency"))
        adj = Gtk.Adjustment(value=p["transparency"], lower=0, upper=90, step_increment=5)
        sc = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL, adjustment=adj)
        sc.set_value_pos(Gtk.PositionType.RIGHT)
        sc.set_size_request(180, -1)
        sc.set_draw_value(True)

        def transparency_changed(w):
            p["transparency"] = int(w.get_value())
            # aplicar en vivo a la ventana
            if self.app.win is not None and self.app.win.get_visible():
                self.app.win._set_wm_opacity(self.app.win._target_opacity())

        sc.connect("value-changed", transparency_changed)
        self._add_row(gr, 0, self.tr("transparency"), sc)
        vb.pack_start(f, False, False, 0)

        return sw

    # ── pestaña Cuota ──
    def _page_quota(self):
        q = self.cfg["quota"]
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        sw.add(vb)

        f, gr = self._frame(self.tr("quota"))
        r = 0
        gr.attach(self._check(("enabled",), "quota"), 0, r, 1, 1)
        gr.attach(Gtk.Label(label=self.tr("q_enabled"), halign=Gtk.Align.START), 1, r, 1, 1)
        r += 1
        cb_period = Gtk.ComboBoxText()
        for label in ("day", "week", "month"):
            cb_period.append_text(self.tr(label))
        cb_period.set_active(["day", "week", "month"].index(q["period_kind"]))
        cb_period.connect("changed", lambda w: q.__setitem__(
            "period_kind", ["day", "week", "month"][w.get_active()]))
        r = self._add_row(gr, r, self.tr("period"), cb_period)
        adj = Gtk.Adjustment(value=q["reset_day_number"], lower=1, upper=28, step_increment=1)
        sp_day = Gtk.SpinButton(adjustment=adj)
        sp_day.set_value(q["reset_day_number"])
        sp_day.connect("value-changed", lambda w: q.__setitem__("reset_day_number", int(w.get_value())))
        r = self._add_row(gr, r, self.tr("reset_day"), sp_day)
        cb_dow = Gtk.ComboBoxText()
        for i, name in enumerate(("monday", "tuesday", "wednesday", "thursday",
                                  "friday", "saturday", "sunday")):
            pass
        cb_dow = Gtk.ComboBoxText()
        from datetime import date
        for i in range(7):
            d = date(2023, 4, 3 + i)   # lunes 3-abr-2023
            cb_dow.append_text(d.strftime("%A"))
        cb_dow.set_active(int(q["reset_day_of_week"]) % 7)
        cb_dow.connect("changed", lambda w: q.__setitem__("reset_day_of_week", w.get_active()))
        r = self._add_row(gr, r, self.tr("reset_dow"), cb_dow)
        e_hour = Gtk.Entry()
        e_hour.set_text(q["reset_hour"])
        e_hour.set_width_chars(6)
        e_hour.connect("changed", lambda w: q.__setitem__("reset_hour", w.get_text()))
        r = self._add_row(gr, r, self.tr("reset_hour"), e_hour)
        vb.pack_start(f, False, False, 0)

        # límite
        f, gr = self._frame(self.tr("limit"))
        adj = Gtk.Adjustment(value=float(q["limit"]["value"]), lower=1, upper=100000, step_increment=1)
        sp_lim = Gtk.SpinButton(adjustment=adj)
        sp_lim.set_value(float(q["limit"]["value"]))
        sp_lim.connect("value-changed", lambda w: q["limit"].__setitem__("value", w.get_value()))
        self._add_row(gr, 0, self.tr("limit"), sp_lim)
        cb_p = Gtk.ComboBoxText()
        for pre in ("", "k", "M", "G", "T"):
            cb_p.append_text(pre if pre else "—")
        cb_p.set_active(["", "k", "M", "G", "T"].index(q["limit"]["prefix"]))
        cb_p.connect("changed", lambda w: q["limit"].__setitem__(
            "prefix", ["", "k", "M", "G", "T"][w.get_active()]))
        cb_k = Gtk.ComboBoxText()
        for k in ("b", "ib", "B", "iB"):
            cb_k.append_text(k)
        cb_k.set_active(["b", "ib", "B", "iB"].index(q["limit"]["kind"]))
        cb_k.connect("changed", lambda w: q["limit"].__setitem__("kind", w.get_active_text()))
        hb = Gtk.Box(spacing=4)
        hb.pack_start(cb_p, False, False, 0)
        hb.pack_start(cb_k, False, False, 0)
        gr.attach(hb, 1, 1, 1, 1)
        vb.pack_start(f, False, False, 0)

        # nota + botón reiniciar contador
        vb.pack_start(Gtk.Label(label=self.tr("q_note"), wrap=True), False, False, 6)
        b_reset_c = Gtk.Button(label=self.tr("reset_counter"))
        b_reset_c.connect("clicked", lambda *_: self.cfg["quota"].__setitem__("used_bytes", 0))
        al = Gtk.Alignment(xalign=0.5)
        al.add(b_reset_c)
        vb.pack_start(al, False, False, 4)
        return sw

    # ── acciones ──
    def on_reset(self, btn):
        from .core import default_settings, deep_merge
        fresh = default_settings()
        # conservar idioma y posición
        fresh["general"]["language"] = self.cfg["general"]["language"]
        fresh["general"]["location"] = self.cfg["general"]["location"]
        self.cfg.clear()
        self.cfg.update(fresh)
        self.destroy()
        self.app.reopen_settings()

    def on_apply(self, btn):
        save_settings(self.cfg)
        self.app.apply_all()

    def on_ok(self, btn):
        self.on_apply(btn)
        self.destroy()
