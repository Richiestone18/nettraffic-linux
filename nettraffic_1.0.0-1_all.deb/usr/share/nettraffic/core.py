#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Núcleo de nettraffic-linux: i18n (es/en), unidades, configuración,
periodo de cuota, lectura de /proc/net/dev y muestreo con estadísticas."""
import glob
import json
import math
import os
import subprocess
import threading
import time
from datetime import datetime, timedelta

APP_ID = "nettraffic-linux"
APP_TITLE = "NetTraffic"
VERSION = "1.0.0"
CONF_DIR = os.path.expanduser("~/.config/nettraffic")
CONF_FILE = os.path.join(CONF_DIR, "settings.json")
STATS_DIR = os.path.join(CONF_DIR, "stats")

# ─────────────────────────── IDIOMAS: solo español e inglés ───────────────────────────
LANGS = {
    "es": {
        "settings": "Ajustes", "statistic": "Estadísticas", "about": "Acerca de...",
        "exit": "Salir", "show": "Mostrar gráfica", "hide": "Ocultar gráfica",
        "window_mode": "Gráfica en ventana con marco", "on_top": "Siempre encima",
        "click_through": "Hacer clic a través", "hide_under_pointer": "Ocultar bajo el puntero",
        "hide_fullscreen": "Ocultar con otra ventana a pantalla completa",
        "general": "General", "chart": "Gráfica", "quota": "Cuota",
        "language": "Idioma", "frequency": "Intervalo de actualización (ms)",
        "interfaces": "Interfaces de red", "if_all": "Usar todas las interfaces",
        "if_selected": "Usar interfaces seleccionadas", "exclude_lo": "Excluir bucle invertido (lo)",
        "behavior": "Comportamiento", "close_tray": "Cerrar a la bandeja",
        "start_system": "Iniciar con el sistema", "start_min": "Iniciar oculto (solo bandeja)",
        "units": "Unidades base", "data_rate": "Velocidad de datos (b/B/ib/iB)",
        "type": "Tipo de gráfica", "shape": "Forma", "points": "Puntos (eje X)",
        "point_width": "Ancho de punto (px)", "buffer": "Puntos en búfer",
        "scale": "Escala máxima (eje Y)", "auto": "Automática", "manual": "Fija",
        "show_dl": "Descarga", "show_ul": "Subida", "show_total": "Total", "show_quota": "Cuota",
        "hide_labels": "Ocultar etiquetas del eje Y", "font_auto": "Auto-escala de fuente",
        "transparency": "Transparencia de la ventana (%)", "theme": "Tema",
        "dark": "Oscuro", "light": "Claro", "colors": "Colores",
        "download": "Descarga", "upload": "Subida", "total": "Total",
        "activity": "Actividad", "background": "Fondo", "font": "Fuente", "axis": "Eje",
        "area": "Área", "column": "Columnas", "line": "Líneas",
        "rectangle": "Rectangular", "pie": "Circular (velocímetro)",
        "title_bar": "Barra de título de la gráfica", "elements": "Elementos",
        "q_enabled": "Conteo habilitado", "limit": "Límite", "period": "Periodo",
        "day": "Día", "week": "Semana", "month": "Mes",
        "reset_day": "Día de reinicio (día del mes)", "reset_dow": "Día de reinicio (día de semana)",
        "reset_hour": "Hora de reinicio (HH:MM)", "reset_counter": "Reiniciar contador ahora",
        "q_note": "Redefinir el inicio del periodo abre un contador nuevo en cero.",
        "used": "Usado", "left": "Restante", "period_end": "Fin del periodo",
        "session": "Sesión actual", "table": "Tabla", "date": "Fecha",
        "export": "Exportar CSV", "clear_data": "Borrar datos",
        "ask_clear": "¿Borrar todas las estadísticas guardadas?",
        "ok": "OK", "apply": "Aplicar", "cancel": "Cancelar", "reset": "Por defecto",
        "no_data": "Sin datos", "avg": "Promedio", "speed": "Velocidad",
        "about_text": "Monitor de tráfico de red para Linux.\nReimplementación libre inspirada en NetTraffic (venea.net).",
        "data": "Datos",
    },
    "en": {
        "settings": "Settings", "statistic": "Statistics", "about": "About...",
        "exit": "Exit", "show": "Show chart", "hide": "Hide chart",
        "window_mode": "Chart in framed window", "on_top": "Always on top",
        "click_through": "Click through", "hide_under_pointer": "Hide under pointer",
        "hide_fullscreen": "Hide when other window is fullscreen",
        "general": "General", "chart": "Chart", "quota": "Quota",
        "language": "Language", "frequency": "Update interval (ms)",
        "interfaces": "Network interfaces", "if_all": "Use all interfaces",
        "if_selected": "Use selected interfaces", "exclude_lo": "Exclude loopback (lo)",
        "behavior": "Behavior", "close_tray": "Close to tray",
        "start_system": "Start with system", "start_min": "Start hidden (tray only)",
        "units": "Base units", "data_rate": "Data rate unit (b/B/ib/iB)",
        "type": "Chart type", "shape": "Shape", "points": "Data points (axis X)",
        "point_width": "Point width (px)", "buffer": "Points in buffer",
        "scale": "Scale maximum (axis Y)", "auto": "Automatic", "manual": "Fixed",
        "show_dl": "Download", "show_ul": "Upload", "show_total": "Total", "show_quota": "Quota",
        "hide_labels": "Hide Y axis labels", "font_auto": "Font auto-scale",
        "transparency": "Window transparency (%)", "theme": "Theme",
        "dark": "Dark", "light": "Light", "colors": "Colors",
        "download": "Download", "upload": "Upload", "total": "Total",
        "activity": "Activity", "background": "Background", "font": "Font", "axis": "Axis",
        "area": "Area", "column": "Column", "line": "Line",
        "rectangle": "Rectangle", "pie": "Circular (speedometer)",
        "title_bar": "Chart title bar", "elements": "Elements",
        "q_enabled": "Counting enabled", "limit": "Limit", "period": "Period",
        "day": "Day", "week": "Week", "month": "Month",
        "reset_day": "Reset day (day of month)", "reset_dow": "Reset day (day of week)",
        "reset_hour": "Reset hour (HH:MM)", "reset_counter": "Reset counter now",
        "q_note": "Redefining period beginning opens a new counter at zero.",
        "used": "Used", "left": "Left", "period_end": "Period end",
        "session": "Current session", "table": "Table", "date": "Date",
        "export": "Export CSV", "clear_data": "Clear data",
        "ask_clear": "Delete all saved statistics?",
        "ok": "OK", "apply": "Apply", "cancel": "Cancel", "reset": "Reset",
        "no_data": "No data", "avg": "Average", "speed": "Speed",
        "about_text": "Network traffic monitor for Linux.\nFree reimplementation inspired by NetTraffic (venea.net).",
        "data": "Data",
    },
}


class Tr:
    """Traductor ligado a la config activa."""
    def __init__(self, cfg):
        self.cfg = cfg

    def __call__(self, key):
        lang = self.cfg["general"]["language"]
        return LANGS.get(lang, LANGS["es"]).get(key, key)


# ─────────────────────────── CONFIGURACIÓN ───────────────────────────
def _colors_dark():
    return {"download": "#22c55e", "upload": "#ef4444", "total": "#3b82f6",
            "activity": "#eab308", "font": "#e2e8f0", "axis": "#64748b", "back": "#1e293b"}


def _colors_light():
    return {"download": "#16a34a", "upload": "#dc2626", "total": "#2563eb",
            "activity": "#ca8a04", "font": "#1e293b", "axis": "#94a3b8", "back": "#f1f5f9"}


def default_settings():
    return {
        "version": 1,
        "general": {
            "language": "es", "frequency_ms": 1000,
            "window_restore": 1, "close_to_tray": True, "on_top": True,
            "click_through": False, "hide_under_pointer": False, "hide_when_fullscreen": False,
            "start_with_system": False,
            "interfaces_mode": "all", "exclude_loopback": True, "selected_interfaces": [],
            "unit_speed": "iB",
            "location": {"x": 60, "y": 40, "width": 320, "height": 120},
        },
        "plot": {
            "theme": "dark", "chart_type": "area", "chart_shape": "rectangle",
            "points_count": 60, "point_width": 3, "points_buffer": 600,
            "scale_y": "auto", "scale_max": {"value": 1, "prefix": "M", "kind": "iB"},
            "show_dl": True, "show_ul": True, "show_total": False, "show_quota": True,
            "hide_y_labels": False, "font_autosize": True, "transparency": 0,
            "window_frame": False, "title_bar": True,
            "colors": {"dark": _colors_dark(), "light": _colors_light()},
        },
        "quota": {
            "enabled": False,
            "limit": {"value": 50, "prefix": "G", "kind": "iB"},
            "period_kind": "month", "reset_day_number": 1, "reset_day_of_week": 0,
            "reset_hour": "00:00", "used_bytes": 0, "period_start": "",
        },
    }


def deep_merge(base, override):
    out = dict(base)
    for k, v in override.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_settings():
    os.makedirs(CONF_DIR, exist_ok=True)
    try:
        with open(CONF_FILE, "r", encoding="utf-8") as f:
            return deep_merge(default_settings(), json.load(f))
    except FileNotFoundError:
        return default_settings()
    except Exception as e:
        print("settings corruptos (%s); usando valores por defecto" % e)
        return default_settings()


def save_settings(cfg):
    os.makedirs(CONF_DIR, exist_ok=True)
    with open(CONF_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


# ─────────────────────────── UNIDADES ───────────────────────────
def fmt_amount(n_bytes, kind, per_second=False):
    """kind: b (bits), ib (bits binarios), B (bytes), iB (bytes binarios)."""
    binary = kind in ("ib", "iB")
    is_bits = kind in ("b", "ib")
    n = float(n_bytes) * (8.0 if is_bits else 1.0)
    div = 1024.0 if binary else 1000.0
    istr = "i" if binary else ""
    unit = "b" if is_bits else "B"
    tail = "/s" if per_second else ""
    for prefix in ("", "k", "M", "G", "T"):
        if n < div:
            if prefix == "":
                return "%.0f %s%s" % (n, unit, tail)
            return "%.2f %s%s%s%s" % (n, prefix, istr, unit, tail)
        n /= div
    return "%.2f T%s%s%s" % (istr, unit, tail)


def parse_amount(value, prefix, kind):
    """(valor, prefijo, tipo) → bytes."""
    mult = 1024 if kind in ("ib", "iB") else 1000
    p = {"": 1, "one": 1, "k": mult, "M": mult ** 2, "G": mult ** 3, "T": mult ** 4}.get(prefix, 1)
    v = float(value) * p
    if kind in ("b", "ib"):
        v /= 8.0
    return v


def hex_to_rgba(hexc, alpha=1.0):
    hexc = hexc.lstrip("#")
    if len(hexc) == 3:
        hexc = "".join(c * 2 for c in hexc)
    return tuple(int(hexc[i:i + 2], 16) / 255.0 for i in (0, 2, 4)) + (alpha,)


def nice_ceil(v):
    if v <= 0:
        return 1.0
    exp = math.floor(math.log10(v))
    base = 10.0 ** exp
    for m in (1, 2, 5, 10):
        if v <= m * base:
            return m * base
    return 10 * base


# ─────────────────────────── /proc/net/dev ───────────────────────────
def read_interfaces():
    ifaces = {}
    try:
        with open("/proc/net/dev", "r", encoding="utf-8") as f:
            lines = f.readlines()
        for line in lines[2:]:
            if ":" not in line:
                continue
            name, rest = line.split(":", 1)
            fields = rest.split()
            if len(fields) >= 9:
                ifaces[name.strip()] = (int(fields[0]), int(fields[8]))
    except Exception:
        pass
    return ifaces


def is_loopback(name):
    return name == "lo" or name.startswith("lo.")


# ─────────────────────────── CUOTA: periodo ───────────────────────────
def _month_start(y, m, day, hh, mm):
    """Inicio del periodo mensual (día clamp al mes). Lanza ValueError si día inválido."""
    import calendar
    day_eff = max(1, min(int(day), calendar.monthrange(y, m)[1]))
    return datetime(y, m, day_eff, hh, mm)


def quota_period_bounds(cfg, now=None):
    """Regresa (inicio, fin) del periodo de cuota vigente."""
    q = cfg["quota"]
    now = now or datetime.now()
    try:
        hh, mm = [int(x) for x in q["reset_hour"].split(":")[:2]]
    except Exception:
        hh, mm = 0, 0
    kind = q["period_kind"]
    if kind == "day":
        start = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if start > now:
            start -= timedelta(days=1)
        return start, start + timedelta(days=1)
    if kind == "week":
        dow = int(q["reset_day_of_week"]) % 7
        start = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        start -= timedelta(days=(start.weekday() - dow) % 7)
        if start > now:
            start -= timedelta(days=7)
        return start, start + timedelta(days=7)
    # mes: día de reinicio (1-28), fin = mismo día del mes siguiente
    day = max(1, min(28, int(q["reset_day_number"])))
    y, m = now.year, now.month
    start = _month_start(y, m, day, hh, mm)
    if start > now:
        m -= 1
        if m == 0:
            y, m = y - 1, 12
        start = _month_start(y, m, day, hh, mm)
    ny, nm = (y + 1, 1) if m == 12 else (y, m + 1)
    return start, _month_start(ny, nm, day, hh, mm)


def quota_period_progress(cfg, now=None):
    now = now or datetime.now()
    start, end = quota_period_bounds(cfg, now)
    total = (end - start).total_seconds()
    if total <= 0:
        return 1.0
    return min(1.0, max(0.0, (now - start).total_seconds() / total))


# ─────────────────────────── PANTALLA COMPLETA (X11) ───────────────────────────
def other_window_fullscreen():
    try:
        out = subprocess.run(["xprop", "-root", "_NET_ACTIVE_WINDOW"],
                             capture_output=True, text=True, timeout=3).stdout
        wid = out.strip().split()[-1]
        if not wid.startswith("0x"):
            return False
        out = subprocess.run(["xprop", "-id", wid, "_NET_WM_STATE"],
                             capture_output=True, text=True, timeout=3).stdout
        return "_NET_WM_STATE_FULLSCREEN" in out
    except Exception:
        return False


# ─────────────────────────── X11 SHAPE (click-through) ───────────────────────────
class X11Shape:
    SHAPE_BOUNDING, SHAPE_INPUT, SHAPE_SET = 0, 2, 0

    def __init__(self):
        self.lib = None
        try:
            import ctypes
            self.ct = ctypes
            self.lib = ctypes.CDLL("libX11.so.6")
            self.lib.XOpenDisplay.restype = ctypes.c_void_p
            self.lib.XShapeCombineRectangles.argtypes = [
                ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
            self.lib.XShapeCombineShape.argtypes = [
                ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                ctypes.c_ulong, ctypes.c_int, ctypes.c_int]
            self.display = self.lib.XOpenDisplay(None)
        except Exception:
            self.lib = None

    def available(self):
        return self.lib is not None and getattr(self, "display", None) is not None

    def set_click_through(self, xid, enabled):
        if not self.available() or not xid:
            return False
        ct = self.ct
        disp = ct.c_void_p(self.display)
        if enabled:
            self.lib.XShapeCombineRectangles(disp, ct.c_ulong(xid), self.SHAPE_INPUT,
                                             0, 0, None, 0, self.SHAPE_SET, 0)
        else:
            self.lib.XShapeCombineShape(disp, ct.c_ulong(xid), self.SHAPE_INPUT, 0, 0,
                                         ct.c_ulong(xid), self.SHAPE_BOUNDING, self.SHAPE_SET)
        self.lib.XFlush(disp)
        return True


# ─────────────────────────── SAMPLER ───────────────────────────
class RateSampler(threading.Thread):
    """Hilo de muestreo: tasas DL/UL, historial, sesión, cuota y estadísticas por mes."""

    def __init__(self, cfg):
        super().__init__(daemon=True)
        self.cfg = cfg
        self.stop_flag = threading.Event()
        self.lock = threading.Lock()
        self.dl_rate = 0.0
        self.ul_rate = 0.0
        self.session_rx = 0.0
        self.session_tx = 0.0
        self.history = []
        self.last = None
        self.month_stats = {"month": "", "days": {}, "hours": {}}
        self._flush_counter = 0
        self._load_month(datetime.now())

    # ── estadísticas por mes (JSON en disco) ──
    def _month_file(self, ym):
        os.makedirs(STATS_DIR, exist_ok=True)
        return os.path.join(STATS_DIR, "%s.json" % ym)

    def _load_month(self, now):
        ym = now.strftime("%Y-%m")
        try:
            with open(self._month_file(ym), "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("month") == ym:
                self.month_stats = data
                return
        except Exception:
            pass
        self.month_stats = {"month": ym, "days": {}, "hours": {}}

    def _flush_month(self):
        try:
            os.makedirs(STATS_DIR, exist_ok=True)
            with open(self._month_file(self.month_stats["month"]), "w", encoding="utf-8") as f:
                json.dump(self.month_stats, f)
        except Exception:
            pass

    def stop(self):
        with self.lock:
            self._flush_month()
        self.stop_flag.set()

    def run(self):
        while not self.stop_flag.is_set():
            t0 = time.monotonic()
            try:
                self._sample_once()
            except Exception:
                pass
            freq = max(0.1, self.cfg["general"]["frequency_ms"] / 1000.0)
            self.stop_flag.wait(max(0.05, freq - (time.monotonic() - t0)))

    def _sample_once(self):
        now_mono = time.monotonic()
        now_dt = datetime.now()
        g = self.cfg["general"]
        ifaces = read_interfaces()
        if g["interfaces_mode"] == "selected" and g["selected_interfaces"]:
            allow = set(g["selected_interfaces"])
            pairs = [v for k, v in ifaces.items() if k in allow]
        else:
            pairs = [v for k, v in ifaces.items()
                     if not (g["exclude_loopback"] and is_loopback(k))]
        rx = sum(v[0] for v in pairs)
        tx = sum(v[1] for v in pairs)

        if self.last is None:
            self.last = (now_mono, rx, tx)
            return
        dt = now_mono - self.last[0]
        if dt <= 0:
            return
        dl = max(0.0, (rx - self.last[1]) / dt)
        ul = max(0.0, (tx - self.last[2]) / dt)
        self.last = (now_mono, rx, tx)

        # ¿inicio de nuevo periodo de cuota? → reiniciar acumulado
        ps_iso = quota_period_bounds(self.cfg, now_dt)[0].isoformat()
        if self.cfg["quota"].get("period_start") != ps_iso:
            self.cfg["quota"]["period_start"] = ps_iso
            self.cfg["quota"]["used_bytes"] = 0

        with self.lock:
            self.dl_rate, self.ul_rate = dl, ul
            self.session_rx += dl * dt
            self.session_tx += ul * dt
            self.cfg["quota"]["used_bytes"] = self.cfg["quota"].get("used_bytes", 0.0) + (dl + ul) * dt
            self.history.append((now_mono, dl, ul))
            buf = max(10, int(self.cfg["plot"]["points_buffer"]))
            if len(self.history) > buf:
                del self.history[:len(self.history) - buf]
            ym = now_dt.strftime("%Y-%m")
            if self.month_stats.get("month") != ym:
                self._flush_month()
                self._load_month(now_dt)
            dkey = now_dt.strftime("%d")
            hkey = now_dt.strftime("%d %H")
            dd = self.month_stats["days"].setdefault(dkey, [0.0, 0.0])
            hh = self.month_stats["hours"].setdefault(hkey, [0.0, 0.0])
            dd[0] += dl * dt; dd[1] += ul * dt
            hh[0] += dl * dt; hh[1] += ul * dt

        self._flush_counter += 1
        if self._flush_counter >= 60:
            self._flush_counter = 0
            with self.lock:
                self._flush_month()

    # ── consultas thread-safe ──
    def get_rates(self):
        with self.lock:
            return self.dl_rate, self.ul_rate

    def get_points(self, n):
        with self.lock:
            return list(self.history[-n:])

    def get_session_totals(self):
        with self.lock:
            return self.session_rx, self.session_tx

    def get_month_stats(self):
        with self.lock:
            return json.loads(json.dumps(self.month_stats))

    def clear_stats(self):
        with self.lock:
            for f in glob.glob(os.path.join(STATS_DIR, "*.json")):
                try:
                    os.remove(f)
                except Exception:
                    pass
            self.month_stats = {"month": datetime.now().strftime("%Y-%m"), "days": {}, "hours": {}}
            self.session_rx = self.session_tx = 0.0
            self._flush_month()
