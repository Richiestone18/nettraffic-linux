#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Icono de bandeja (AyatanaAppIndicator3) dibujado dinámicamente:
estados TX+RX / solo TX / solo RX / inactivo (como el original) y, con cuota
habilitada, barra superior = % del límite usado, barra inferior = transcurso del periodo."""
import os
import tempfile

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('AyatanaAppIndicator3', '0.1')
from gi.repository import AyatanaAppIndicator3 as AppIndicator
import cairo

from .core import parse_amount, quota_period_progress, hex_to_rgba

ICON_SIZE = 22
ACTIVITY_THRESHOLD = 1024.0   # 1 kiB/s


class TrayIcon:
    def __init__(self, app):
        self.app = app
        self.cfg = app.cfg
        self.indicator = AppIndicator.Indicator.new(
            "nettraffic", "network-transmit-receive",
            AppIndicator.IndicatorCategory.APPLICATION_STATUS)
        self.indicator.set_status(AppIndicator.IndicatorStatus.ACTIVE)
        self.icon_dir = tempfile.mkdtemp(prefix="nettraffic-tray-")
        self.icon_path = os.path.join(self.icon_dir, "icon.png")
        self.update(force=True)
        self.indicator.set_menu(self.app.menu)
        self.indicator.set_title("NetTraffic")

    def update(self, force=False):
        dl, ul = self.app.sampler.get_rates()
        q = self.cfg["quota"]
        if q["enabled"]:
            limit = parse_amount(q["limit"]["value"], q["limit"]["prefix"], q["limit"]["kind"])
            used = q.get("used_bytes", 0)
            quota_pct = min(1.0, used / limit) if limit > 0 else 0.0
            period_pct = quota_period_progress(self.cfg)
        else:
            quota_pct, period_pct = None, None
        rx_active = dl > ACTIVITY_THRESHOLD
        tx_active = ul > ACTIVITY_THRESHOLD
        sig = (rx_active, tx_active, quota_pct, None if period_pct is None else round(period_pct, 3),
               self.cfg["plot"]["theme"])
        if sig == self._sig and not force:
            return
        self._sig = sig
        self._render(rx_active, tx_active, quota_pct, period_pct)
        try:
            self.indicator.set_icon_full(self.icon_path, "NetTraffic")
        except Exception:
            try:
                self.indicator.set_icon(self.icon_path)
            except Exception:
                pass

    _sig = None

    def _render(self, rx_active, tx_active, quota_pct, period_pct):
        s = ICON_SIZE
        theme = self.cfg["plot"]["colors"].get(self.cfg["plot"]["theme"],
                                               self.cfg["plot"]["colors"]["dark"])
        surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, s, s)
        cr = cairo.Context(surface)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.rectangle(0, 0, s, s)
        cr.fill()

        if not rx_active and not tx_active:
            # estado inactivo: dos monitores apagados
            self._monitor(cr, 2, 4, 7, on=False, color=None)
            self._monitor(cr, 12, 9, 7, on=False, color=None)
        elif rx_active and tx_active:
            self._monitor(cr, 2, 4, 7, on=True, color=theme["download"])
            self._monitor(cr, 12, 9, 7, on=True, color=theme["upload"])
        elif rx_active:
            self._monitor(cr, 3, 6, 8, on=True, color=theme["download"])
        else:
            self._monitor(cr, 9, 6, 8, on=True, color=theme["upload"])

        if quota_pct is not None:
            bar_w = s - 2
            # barra superior: uso del límite
            col = (theme["download"] if quota_pct < 0.8 else
                   (theme["activity"] if quota_pct < 1.0 else theme["upload"]))
            cr.set_source_rgba(0, 0, 0, 0.55)
            cr.rectangle(1, 0, bar_w, 3)
            cr.fill()
            cr.set_source_rgba(*hex_to_rgba(col))
            cr.rectangle(1, 0, bar_w * quota_pct, 3)
            cr.fill()
            # barra inferior: transcurso del periodo
            cr.set_source_rgba(0, 0, 0, 0.55)
            cr.rectangle(1, s - 3, bar_w, 2)
            cr.fill()
            cr.set_source_rgba(*hex_to_rgba(theme["total"]))
            cr.rectangle(1, s - 3, bar_w * (period_pct or 0.0), 2)
            cr.fill()

        surface.write_to_png(self.icon_path)

    def _monitor(self, cr, x, y, size, on, color):
        """Mini-monitor estilo NetTraffic (pantalla + peana)."""
        cr.set_line_width(1.0)
        cr.set_source_rgba(0.85, 0.85, 0.85, 0.9)
        cr.rectangle(x, y, size, size * 0.72)
        cr.stroke()
        cr.move_to(x + size * 0.2, y + size * 0.78)
        cr.line_to(x + size * 0.8, y + size * 0.78)
        cr.stroke()
        if on and color:
            cr.set_source_rgba(*hex_to_rgba(color, 0.95))
            cr.rectangle(x + 1.5, y + 1.5, size - 3, size * 0.72 - 3)
            cr.fill()
        else:
            cr.set_source_rgba(0.35, 0.35, 0.35, 0.5)
            cr.rectangle(x + 1.5, y + 1.5, size - 3, size * 0.72 - 3)
            cr.fill()

    def set_menu(self, menu):
        self.indicator.set_menu(menu)

    def hide(self):
        self.indicator.set_status(AppIndicator.IndicatorStatus.PASSIVE)
