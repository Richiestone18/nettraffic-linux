#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Aplicación principal: sampler + ventana + bandeja + menú + ajustes + estadísticas."""
import os
import signal
import subprocess
import sys
from datetime import datetime

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('AyatanaAppIndicator3', '0.1')
from gi.repository import Gtk, GLib

from .core import (APP_TITLE, VERSION, CONF_DIR, RateSampler, Tr, X11Shape,
                   load_settings, save_settings, fmt_amount, parse_amount,
                   quota_period_bounds)
from .chart import ChartWindow
from .tray import TrayIcon
from .settings import SettingsWindow
from .stats import StatsWindow

AUTOSTART_FILE = os.path.expanduser("~/.config/autostart/nettraffic.desktop")


class App:
    def __init__(self):
        self.cfg = load_settings()
        self.tr = Tr(self.cfg)
        self.x11shape = X11Shape()
        self.started_at = datetime.now()
        self.win = None
        self.tray = None
        self.menu = self._build_menu()
        self.settings_win = None
        self.stats_win = None

        self.sampler = RateSampler(self.cfg)
        self.sampler.start()

        self.win = ChartWindow(self)
        self.win.restore_state()
        self.tray = TrayIcon(self)
        self.tray.set_menu(self.menu)
        self.apply_autostart()

        # guardar settings al salir + cada 5 min (por si algo falla)
        GLib.timeout_add(300000, self._autosave)
        # refresco del icono de bandeja
        GLib.timeout_add(1000, self._tick_tray)

    # ── menú (como el menú contextual del original) ──
    def _build_menu(self):
        m = Gtk.Menu()

        def item(label, cb, check=False):
            if check:
                it = Gtk.CheckMenuItem(label=label)
            else:
                it = Gtk.MenuItem(label=label)
            it.connect("activate", cb)
            m.append(it)
            return it

        self.mi_show = item(self.tr("show"), self.on_toggle_show)
        self.mi_on_top = item(self.tr("on_top"), self.on_toggle_on_top, check=True)
        self.mi_on_top.set_active(bool(self.cfg["general"]["on_top"]))
        self.mi_click_through = item(self.tr("click_through"), self.on_toggle_ct, check=True)
        self.mi_click_through.set_active(bool(self.cfg["general"]["click_through"]))
        self.mi_hide_ptr = item(self.tr("hide_under_pointer"), self.on_toggle_hptr, check=True)
        self.mi_hide_ptr.set_active(bool(self.cfg["general"]["hide_under_pointer"]))
        m.append(Gtk.SeparatorMenuItem())
        self.mi_settings = item(self.tr("settings"), self.on_settings)
        self.mi_stats = item(self.tr("statistic"), self.on_stats)
        self.mi_about = item(self.tr("about"), self.on_about)
        m.append(Gtk.SeparatorMenuItem())
        self.mi_exit = item(self.tr("exit"), self.on_exit)
        m.show_all()
        return m

    def refresh_menu_labels(self):
        self.mi_show.set_label(self.tr("show") if not self.win.get_visible() else self.tr("hide"))
        self.mi_on_top.set_label(self.tr("on_top"))
        self.mi_click_through.set_label(self.tr("click_through"))
        self.mi_hide_ptr.set_label(self.tr("hide_under_pointer"))
        self.mi_settings.set_label(self.tr("settings"))
        self.mi_stats.set_label(self.tr("statistic"))
        self.mi_about.set_label(self.tr("about"))
        self.mi_exit.set_label(self.tr("exit"))

    # ── acciones del menú ──
    def on_toggle_show(self, *_):
        if self.win.get_visible():
            self.win.hide()
        else:
            self.win.show()
        self.refresh_menu_labels()

    def on_toggle_on_top(self, item):
        self.cfg["general"]["on_top"] = item.get_active()
        self.apply_all()

    def on_toggle_ct(self, item):
        self.cfg["general"]["click_through"] = item.get_active()
        self.apply_all()

    def on_toggle_hptr(self, item):
        self.cfg["general"]["hide_under_pointer"] = item.get_active()
        self.apply_all()

    def on_settings(self, *_):
        if self.settings_win:
            self.settings_win.present()
            return
        self.settings_win = SettingsWindow(self)
        self.settings_win.connect("destroy", self._settings_closed)
        self.settings_win.show_all()

    def _settings_closed(self, *_):
        self.settings_win = None

    def reopen_settings(self):
        GLib.idle_add(self.on_settings)

    def on_stats(self, *_):
        if self.stats_win:
            self.stats_win.present()
            return
        self.stats_win = StatsWindow(self)
        self.stats_win.connect("destroy", lambda *_: setattr(self, "stats_win", None))
        self.stats_win.show_all()

    def on_about(self, *_):
        dlg = Gtk.MessageDialog(message_type=Gtk.MessageType.INFO, buttons=Gtk.ButtonsType.OK)
        dlg.set_title(self.tr("about"))
        dlg.props.text = "NetTraffic Linux %s" % VERSION
        dlg.props.secondary_text = self.tr("about_text")
        dlg.run()
        dlg.destroy()

    def on_exit(self, *_):
        self.quit()

    # ── ciclo de vida ──
    def apply_all(self):
        """Propaga la config a ventana/bandeja y guarda."""
        if self.win:
            self.win.apply_config()
        if self.tray:
            self.tray.update(force=True)
        save_settings(self.cfg)

    def _autosave(self):
        save_settings(self.cfg)
        return True

    def _tick_tray(self):
        self.tray.update()
        if self.settings_win is None and self.stats_win is not None:
            pass
        return True

    def apply_autostart(self):
        if self.cfg["general"].get("start_with_system"):
            os.makedirs(os.path.dirname(AUTOSTART_FILE), exist_ok=True)
            cmd = "nettraffic"
            with open(AUTOSTART_FILE, "w", encoding="utf-8") as f:
                f.write("[Desktop Entry]\nType=Application\nName=NetTraffic\n"
                        "Exec=%s\nTerminal=false\nX-GNOME-Autostart-enabled=true\n" % cmd)
        else:
            try:
                os.remove(AUTOSTART_FILE)
            except FileNotFoundError:
                pass

    def quit(self):
        try:
            self.sampler.stop()
        except Exception:
            pass
        save_settings(self.cfg)
        Gtk.main_quit()

    def run(self):
        Gtk.main()


def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    if os.environ.get("NETTRAFFIC_DEBUG"):
        import traceback
        sys.excepthook = lambda t, v, x: (traceback.print_exception(t, v, x), Gtk.main_quit())
    app = App()
    app.run()


if __name__ == "__main__":
    main()
