#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Ventana de Estadísticas fiel al original:
  - General: Estado actual / Promedio / Pronóstico (Descarga, Subida, Total,
    Tiempo) + bloque de Cuota (Usado, Límite, Restante, Inicio, Final, Factor,
    Mínimo/Máximo), con ajuste del contador.
  - Gráficos / tablas: rango de fechas + unidad de tiempo + Buscar;
    sub-pestañas Gráfico (barras) y Tabla (Fecha, Recibido, Enviado, Total, Tiempo).

Unidades: Día = un renglón por día; Mes = un renglón por mes (agregado);
Año = un renglón por año; Hora = un renglón por hora. Antes Mes y Año
devolvían lo mismo que Día (bug corregido).
"""
import csv
import calendar
from datetime import datetime, timedelta

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk

from .core import (fmt_amount, parse_amount, quota_period_bounds, quota_period_progress,
                   theme_colors, hex_to_rgba, available_months, iter_month_data,
                   q_enabled)

UNITS = ("hour", "day", "month", "year")
KIND = "iB"


def _fmt_duration(sec):
    """d hh:mm:ss — como el 'Time' del original (0d 01:27:12)."""
    sec = max(0, int(sec))
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return "%dd %02d:%02d:%02d" % (d, h, m, s)


def summary_values(app, now=None):
    """Números del bloque General. Función pura para poder probarla sin GUI.

    Pronóstico: extrapola la sesión al final del periodo vigente (de cuota si
    está habilitada, si no al final del día). Antes se multiplicaba por la
    fracción transcurrida, lo que daba un valor MENOR al actual (bug corregido).
    """
    now = now or datetime.now()
    rx, tx = app.sampler.get_session_totals()
    dur = (now - app.started_at).total_seconds()
    dur = max(1.0, dur)
    avg_rx, avg_tx = rx / dur, tx / dur

    if q_enabled(app.cfg):
        _, window_end = quota_period_bounds(app.cfg, now)
    else:
        window_end = datetime(now.year, now.month, now.day) + timedelta(days=1)
    span = (window_end - app.started_at).total_seconds()
    frac = dur / span if span > 0 else 1.0
    frac = max(1e-6, min(1.0, frac))
    prog_rx, prog_tx = rx / frac, tx / frac

    return {"rx": rx, "tx": tx, "dur": dur,
            "avg_rx": avg_rx, "avg_tx": avg_tx,
            "prog_rx": prog_rx, "prog_tx": prog_tx,
            "prog_frac": frac, "window_end": window_end}


def quota_values(app, now=None):
    """Números del bloque de Cuota (o None si el conteo está apagado)."""
    now = now or datetime.now()
    q = app.cfg["quota"]
    if not q_enabled(app.cfg):
        return None
    limit = parse_amount(q["limit"]["value"], q["limit"]["prefix"], q["limit"]["kind"])
    used = float(q.get("used_bytes", 0.0))
    start, end = quota_period_bounds(app.cfg, now)
    elapsed = max(0.0, (now - start).total_seconds())
    length = max(1.0, (end - start).total_seconds())
    # Factor: ritmo de consumo proyectado (bytes del periodo, no por segundo)
    factor = used / elapsed * length if elapsed > 0 else 0.0
    scope = q.get("scope", "all")
    scope_name = None
    if scope == "iface":
        scope_name = q.get("iface_active") or q.get("interface") or ""
    return {"limit": limit, "used": used, "left": max(0.0, limit - used),
            "start": start, "end": end, "factor": factor,
            "pct": (used / limit) if limit > 0 else 0.0,
            "period_pct": quota_period_progress(app.cfg, now),
            "min": q.get("period_min"), "max": q.get("period_max"),
            "max_day": q.get("period_max_day") or "",
            "scope": scope, "scope_name": scope_name,
            "period_kind": q.get("period_kind", "month")}


def aggregate_rows(app, months, y0, m0, d0, y1, m1, d1, unit):
    """Renglones (label, rx, tx, secs) del rango pedido, agregados por unidad."""
    start = datetime(y0, m0, d0)
    end = datetime(y1, m1, d1, 23, 59, 59)
    cur_ym = app.sampler.month_stats.get("month")
    cur = app.sampler.get_month_stats()
    acc = {}          # clave -> [label, rx, tx, secs, orden]

    def add(key, order_key, label, rx, tx, secs):
        row = acc.get(key)
        if row is None:
            acc[key] = [label, float(rx), float(tx), float(secs), order_key]
        else:
            row[1] += float(rx)
            row[2] += float(tx)
            row[3] += float(secs)

    for ym, data in iter_month_data(months, cur_ym, cur):
        try:
            yy, mm = int(ym[:4]), int(ym[5:7])
        except Exception:
            continue
        if unit == "hour":
            for hkey, vals in data.get("hours", {}).items():
                try:
                    dstr, hstr = hkey.split()
                    dt = datetime(yy, mm, int(dstr), int(hstr))
                except Exception:
                    continue
                if start <= dt <= end:
                    add(dt, dt, dt.strftime("%Y-%m-%d %H:00"), vals[0], vals[1],
                        data.get("hour_secs", {}).get(hkey, 3600.0))
            continue
        days = data.get("days", {})
        if unit == "day":
            for dkey, vals in days.items():
                try:
                    dt = datetime(yy, mm, int(dkey))
                except Exception:
                    continue
                if start <= dt <= end:
                    add(dt, dt, dt.strftime("%Y-%m-%d"), vals[0], vals[1],
                        data.get("day_secs", {}).get(dkey, 86400.0))
        elif unit == "month":
            first = datetime(yy, mm, 1)
            last = datetime(yy, mm, calendar.monthrange(yy, mm)[1], 23, 59)
            if last < start or first > end:
                continue
            secs = sum(float(data.get("day_secs", {}).get(k, 86400.0)) for k in days)
            rx = sum(v[0] for v in days.values())
            tx = sum(v[1] for v in days.values())
            add((yy, mm), first, "%04d-%02d" % (yy, mm), rx, tx, secs)
        elif unit == "year":
            if not (start.year <= yy <= end.year):
                continue
            from_dt = start if yy == start.year else datetime(yy, 1, 1)
            to_dt = end if yy == end.year else datetime(yy, 12, 31, 23, 59)
            rx = tx = secs = 0.0
            for dkey, vals in days.items():
                try:
                    dt = datetime(yy, mm, int(dkey))
                except Exception:
                    continue
                if from_dt <= dt <= to_dt:
                    rx += vals[0]
                    tx += vals[1]
                    secs += float(data.get("day_secs", {}).get(dkey, 86400.0))
            if rx or tx:
                add(yy, datetime(yy, 1, 1), "%04d" % yy, rx, tx, secs)
    return [(r[0], r[1], r[2], r[3]) for r in sorted(acc.values(), key=lambda r: r[4])]


class StatsWindow(Gtk.Window):
    def __init__(self, app):
        super().__init__(title=app.tr("statistic"))
        self.app = app
        self.cfg = app.cfg
        self.tr = app.tr
        self._last_rows = []
        self.set_default_size(660, 500)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        vb.set_border_width(8)
        self.add(vb)

        nb = Gtk.Notebook()
        vb.pack_start(nb, True, True, 0)
        nb.append_page(self._page_general(), Gtk.Label(label=self.tr("stat_general")))
        nb.append_page(self._page_advanced(), Gtk.Label(label=self.tr("stat_advanced")))

        hb = Gtk.Box(spacing=6, halign=Gtk.Align.END)
        vb.pack_start(hb, False, False, 4)
        b_data = Gtk.Button(label=self.tr("data"))
        b_data.connect("clicked", self.on_data_menu)
        hb.pack_start(b_data, False, False, 0)
        b_close = Gtk.Button(label=self.tr("ok"))
        b_close.connect("clicked", lambda *_: self.destroy())
        hb.pack_start(b_close, False, False, 0)

    # ── helpers de UI ──
    def _row(self, g, r, label, value, bold=False):
        lbl = Gtk.Label(label=label, halign=Gtk.Align.START)
        val = Gtk.Label(label=value, halign=Gtk.Align.END, selectable=True)
        if bold:
            for w in (lbl, val):
                w.set_markup("<b>%s</b>" % Gtk.Label.escape(w.get_text()))
        g.attach(lbl, 0, r, 1, 1)
        g.attach(val, 1, r, 1, 1)
        return r + 1

    def _block(self, title, rows):
        f = Gtk.Frame(label=title)
        f.set_border_width(4)
        g = Gtk.Grid(column_spacing=16, row_spacing=4, margin=6)
        f.add(g)
        r = 0
        for label, value in rows:
            r = self._row(g, r, label, value)
        return f

    # ── pestaña General (resumen) ──
    def _page_general(self):
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        # altura mínima: sin esto la ventana crece con el contenido en vez de
        # desplazarse y el bloque de Cuota queda fuera de pantalla
        sw.set_min_content_height(360)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        sw.add(vb)
        self._general_box = vb
        self.refresh_general()
        return sw

    def refresh_general(self):
        for child in list(self._general_box.get_children()):
            self._general_box.remove(child)
        s = summary_values(self.app)
        k = KIND
        blocks = [
            (self.tr("stat_now"),
             [(self.tr("download"), fmt_amount(s["rx"], k)),
              (self.tr("upload"), fmt_amount(s["tx"], k)),
              (self.tr("total"), fmt_amount(s["rx"] + s["tx"], k)),
              (self.tr("stat_time"), _fmt_duration(s["dur"]))]),
            (self.tr("stat_avg2"),
             [(self.tr("download"), fmt_amount(s["avg_rx"], k, per_second=True)),
              (self.tr("upload"), fmt_amount(s["avg_tx"], k, per_second=True)),
              (self.tr("total"), fmt_amount(s["avg_rx"] + s["avg_tx"], k, per_second=True))]),
            (self.tr("stat_prognosis"),
             [(self.tr("download"), fmt_amount(s["prog_rx"], k)),
              (self.tr("upload"), fmt_amount(s["prog_tx"], k)),
              (self.tr("total"), fmt_amount(s["prog_rx"] + s["prog_tx"], k)),
              (self.tr("period_end"), s["window_end"].strftime("%Y-%m-%d %H:%M"))]),
        ]
        q = quota_values(self.app)
        if q:
            kind = self.cfg["quota"]["limit"]["kind"]
            used_rows = [
                (self.tr("stat_q_used"), fmt_amount(q["used"], kind)),
                (self.tr("stat_q_limit"), fmt_amount(q["limit"], kind)),
                (self.tr("stat_q_left"), fmt_amount(q["left"], kind)),
                (self.tr("stat_q_period"), "%s  (%.0f%% / %.0f%%)" % (
                    self.tr({"day": "day", "week": "week", "month": "month"}.get(
                        q["period_kind"], "month")),
                    q["pct"] * 100.0, q["period_pct"] * 100.0)),
                (self.tr("stat_q_begin"), q["start"].strftime("%Y-%m-%d %H:%M")),
                (self.tr("stat_q_end"), q["end"].strftime("%Y-%m-%d %H:%M")),
                (self.tr("stat_q_factor"), fmt_amount(q["factor"], kind)),
            ]
            if q["min"] is not None:
                used_rows.append((self.tr("quota_min"), fmt_amount(q["min"], kind)))
            if q["max"] is not None:
                extra = (" (%s)" % q["max_day"]) if q["max_day"] else ""
                used_rows.append((self.tr("quota_max"),
                                  fmt_amount(q["max"], kind) + extra))
            blocks.append((self.tr("quota"), used_rows))

        for title, rows in blocks:
            self._general_box.pack_start(self._block(title, rows), False, False, 0)

        if q:
            al = Gtk.Alignment(xalign=0.5, yalign=0.5)
            b = Gtk.Button(label=self.tr("stat_q_adjust"))
            b.connect("clicked", self.on_adjust_quota)
            al.add(b)
            self._general_box.pack_start(al, False, False, 6)
        self._general_box.show_all()

    # ── pestaña Gráficos / tablas ──
    def _page_advanced(self):
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        now = datetime.now()

        bar = Gtk.Box(spacing=6)
        bar.pack_start(Gtk.Label(label=self.tr("stat_from")), False, False, 0)
        self.spin_f = self._date_spinbox(now - timedelta(days=30), now)
        bar.pack_start(self.spin_f, False, False, 0)
        bar.pack_start(Gtk.Label(label=self.tr("stat_to")), False, False, 0)
        self.spin_t = self._date_spinbox(now, now)
        bar.pack_start(self.spin_t, False, False, 0)
        bar.pack_start(Gtk.Label(label=self.tr("stat_time_unit")), False, False, 0)
        cb_unit = Gtk.ComboBoxText()
        for k in ("unit_hour", "unit_day", "unit_month", "unit_year"):
            cb_unit.append_text(self.tr(k))
        cb_unit.set_active(1)  # Día
        self.unit = "day"
        cb_unit.connect("changed", lambda w: setattr(self, "unit", UNITS[w.get_active()]))
        bar.pack_start(cb_unit, False, False, 0)
        b_find = Gtk.Button(label=self.tr("stat_find"))
        b_find.connect("clicked", self.on_find)
        bar.pack_start(b_find, False, False, 0)
        vb.pack_start(bar, False, False, 0)

        self.nb2 = Gtk.Notebook()
        vb.pack_start(self.nb2, True, True, 0)
        self.nb2.append_page(self._page_chart(), Gtk.Label(label=self.tr("stat_plot")))
        self.nb2.append_page(self._page_table(), Gtk.Label(label=self.tr("stat_table")))

        self._last_rows = []
        GLib_idle = self.on_find   # primer llenado
        GLib_idle()
        return vb

    def _date_spinbox(self, dt, hi):
        hb = Gtk.Box(spacing=2)
        spins = []
        for val, lo_i, hi_i in ((dt.year, 2007, hi.year), (dt.month, 1, 12), (dt.day, 1, 31)):
            sp = Gtk.SpinButton.new_with_range(lo_i, hi_i, 1)
            sp.set_value(val)
            sp.set_digits(0)
            if lo_i == hi_i:
                sp.set_sensitive(False)
            spins.append(sp)
            hb.pack_start(sp, False, False, 0)
        hb._spins = spins
        return hb

    def _get_date(self, widget):
        y, m, d = (int(s.get_value()) for s in widget._spins)
        m = max(1, min(12, m))
        # un mes corto no admite día 31: se ajusta al último día real
        d = max(1, min(d, calendar.monthrange(y, m)[1]))
        return y, m, d

    def _page_chart(self):
        sw = Gtk.ScrolledWindow()
        self.chart_draw = Gtk.DrawingArea()
        self.chart_draw.connect("draw", self.on_draw_chart)
        self.chart_draw.set_size_request(-1, 200)
        sw.add(self.chart_draw)
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.set_min_content_height(220)
        return sw

    def _page_table(self):
        sw = Gtk.ScrolledWindow()
        sw.set_min_content_height(220)
        self.table_store = Gtk.ListStore(str, str, str, str, str)
        tv = Gtk.TreeView(model=self.table_store)
        cols = ((self.tr("date"), 0.0), (self.tr("stat_received"), 1.0),
                (self.tr("stat_sent"), 1.0), (self.tr("total"), 1.0),
                (self.tr("stat_time"), 1.0))
        for i, (title, align) in enumerate(cols):
            r = Gtk.CellRendererText()
            if i > 0:
                r.set_property("xalign", 1.0)
            col = Gtk.TreeViewColumn(title, r, text=i)
            col.set_alignment(align)
            col.set_expand(i == 0)
            tv.append_column(col)
        sw.add(tv)
        return sw

    def on_find(self, *_):
        try:
            y0, m0, d0 = self._get_date(self.spin_f)
            y1, m1, d1 = self._get_date(self.spin_t)
        except Exception:
            return
        if (y0, m0, d0) > (y1, m1, d1):
            y0, m0, d0, y1, m1, d1 = y1, m1, d1, y0, m0, d0
        rows = aggregate_rows(self.app, available_months(), y0, m0, d0, y1, m1, d1, self.unit)
        self._last_rows = rows
        self.table_store.clear()
        for label, rx, tx, secs in rows:
            self.table_store.append([label, fmt_amount(rx, KIND), fmt_amount(tx, KIND),
                                     fmt_amount(rx + tx, KIND), _fmt_duration(secs)])
        self.chart_draw.queue_draw()

    def on_draw_chart(self, da, cr):
        rows = self._last_rows
        w = max(1, da.get_allocated_width())
        h = max(1, da.get_allocated_height())
        theme = theme_colors(self.cfg)
        cr.set_source_rgba(*hex_to_rgba(theme["back"]))
        cr.rectangle(0, 0, w, h)
        cr.fill()
        if not rows:
            cr.set_source_rgba(*hex_to_rgba(theme["font"], 0.7))
            cr.select_font_face("Sans", 0, 1)
            cr.set_font_size(12)
            txt = self.tr("stat_no_data")
            cr.move_to(max(6, (w - cr.text_extents(txt).width) / 2), h / 2)
            cr.show_text(txt)
            return False

        # margen izquierdo para etiquetas del eje Y
        cr.select_font_face("Sans", 0, 1)
        cr.set_font_size(8)
        maxv = max(rx + tx for _, rx, tx, _s in rows) or 1.0
        pad_l = 6 + max(cr.text_extents(fmt_amount(maxv * i / 4.0, KIND)).width
                        for i in range(5))
        pad_b, pad_t, pad_r = 20, 8, 6
        plot_w = max(10, w - pad_l - pad_r)
        plot_h = max(10, h - pad_t - pad_b)

        def ypos(v):
            return pad_t + plot_h - min(1.0, v / maxv) * plot_h

        # rejilla + etiquetas
        for i in range(5):
            frac = i / 4.0
            y = pad_t + plot_h - plot_h * frac
            cr.set_source_rgba(*hex_to_rgba(theme["axis"], 0.35))
            cr.set_line_width(0.5)
            cr.move_to(pad_l, y)
            cr.line_to(pad_l + plot_w, y)
            cr.stroke()
            lbl = fmt_amount(maxv * frac, KIND)
            cr.set_source_rgba(*hex_to_rgba(theme["font"], 0.75))
            cr.move_to(max(1, pad_l - 4 - cr.text_extents(lbl).width), y + 3)
            cr.show_text(lbl)

        n = len(rows)
        step = plot_w / float(n)
        bw = max(2.0, min(step * 0.8, 42.0))
        for i, (_label, rx, tx, _secs) in enumerate(rows):
            x0 = pad_l + step * i + (step - bw) / 2.0
            # barra apilada: descarga (abajo, verde) + subida (arriba, roja)
            hr = (rx / maxv) * plot_h
            hu = (tx / maxv) * plot_h
            cr.set_source_rgba(*hex_to_rgba(theme["download"], 0.95))
            cr.rectangle(x0, pad_t + plot_h - hr, bw, hr)
            cr.fill()
            cr.set_source_rgba(*hex_to_rgba(theme["upload"], 0.95))
            cr.rectangle(x0, pad_t + plot_h - hr - hu, bw, hu)
            cr.fill()

        cr.set_source_rgba(*hex_to_rgba(theme["axis"], 0.8))
        cr.set_line_width(0.8)
        cr.move_to(pad_l, pad_t + plot_h)
        cr.line_to(pad_l + plot_w, pad_t + plot_h)
        cr.stroke()
        return False

    # ── Datos: Exportar / Borrar / Ajustar ──
    def on_data_menu(self, btn):
        m = Gtk.Menu()
        it_exp = Gtk.MenuItem(label=self.tr("stat_data_export"))
        it_exp.connect("activate", self.on_export)
        m.append(it_exp)
        it_del = Gtk.MenuItem(label=self.tr("stat_data_delete"))
        it_del.connect("activate", self.on_clear)
        m.append(it_del)
        if q_enabled(self.cfg):
            m.append(Gtk.SeparatorMenuItem())
            it_adj = Gtk.MenuItem(label=self.tr("stat_q_adjust"))
            it_adj.connect("activate", self.on_adjust_quota)
            m.append(it_adj)
        m.show_all()
        m.popup_at_widget(btn, Gdk.Gravity.SOUTH_WEST, Gdk.Gravity.NORTH_WEST, None)

    def on_export(self, *_):
        dlg = Gtk.FileChooserNative.new(self.tr("stat_data_export"), self,
                                        Gtk.FileChooserAction.SAVE, None, None)
        dlg.set_current_name("nettraffic-%s.csv" % datetime.now().strftime("%Y%m%d"))
        dlg.set_do_overwrite_confirmation(True)
        if dlg.run() != Gtk.ResponseType.ACCEPT:
            dlg.destroy()
            return
        path = dlg.get_filename()
        dlg.destroy()
        months = available_months()
        cur_ym = self.app.sampler.month_stats.get("month")
        cur = self.app.sampler.get_month_stats()
        try:
            with open(path, "w", encoding="utf-8", newline="") as f:
                w = csv.writer(f)
                w.writerow(["date", "received_bytes", "sent_bytes", "total_bytes",
                            "received", "sent", "total", "seconds"])
                for ym, data in iter_month_data(months, cur_ym, cur):
                    for dkey in sorted(data.get("days", {})):
                        rx, tx = data["days"][dkey]
                        secs = data.get("day_secs", {}).get(dkey, "")
                        w.writerow(["%s-%s" % (ym, dkey), int(rx), int(tx), int(rx + tx),
                                    fmt_amount(rx, KIND), fmt_amount(tx, KIND),
                                    fmt_amount(rx + tx, KIND), round(float(secs), 1) if secs != "" else ""])
            self._info("%s\n%s" % (self.tr("stat_data_export"), path))
        except Exception as e:
            self._info(str(e))

    def _info(self, text):
        dlg = Gtk.MessageDialog(transient_for=self, modal=True,
                                message_type=Gtk.MessageType.INFO,
                                buttons=Gtk.ButtonsType.OK, text=text)
        dlg.run()
        dlg.destroy()

    def on_clear(self, *_):
        dlg = Gtk.MessageDialog(transient_for=self, modal=True,
                                message_type=Gtk.MessageType.QUESTION,
                                buttons=Gtk.ButtonsType.YES_NO,
                                text=self.tr("stat_ask_clear"))
        resp = dlg.run()
        dlg.destroy()
        if resp == Gtk.ResponseType.YES:
            self.app.sampler.clear_stats()
            self._last_rows = []
            self.table_store.clear()
            self.chart_draw.queue_draw()
            self.refresh_general()

    # ── Ajustar contador de cuota ──
    def on_adjust_quota(self, *_):
        q = self.cfg["quota"]
        dialog = Gtk.Dialog(title=self.tr("stat_q_adjust"), transient_for=self, modal=True)
        dialog.add_button(self.tr("cancel"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self.tr("ok"), Gtk.ResponseType.OK)
        area = dialog.get_content_area()
        area.set_spacing(6)
        area.set_border_width(10)
        area.add(Gtk.Label(label=self.tr("q_note"), wrap=True, halign=Gtk.Align.START))
        adj = Gtk.Adjustment(value=float(q["limit"]["value"]), lower=0, upper=100000,
                             step_increment=1)
        sp = Gtk.SpinButton(adjustment=adj, digits=2)
        sp.set_value(float(q["limit"]["value"]))
        cb_p = Gtk.ComboBoxText()
        for pre in ("", "k", "M", "G", "T"):
            cb_p.append_text(pre if pre else "—")
        cb_p.set_active(["", "k", "M", "G", "T"].index(q["limit"]["prefix"]))
        cb_k = Gtk.ComboBoxText()
        for kk in ("b", "ib", "B", "iB"):
            cb_k.append_text(kk)
        cb_k.set_active(["b", "ib", "B", "iB"].index(q["limit"]["kind"]))
        hb = Gtk.Box(spacing=4)
        hb.pack_start(Gtk.Label(label=self.tr("stat_q_used")), False, False, 0)
        hb.pack_start(sp, False, False, 0)
        hb.pack_start(cb_p, False, False, 0)
        hb.pack_start(cb_k, False, False, 0)
        area.add(hb)
        area.add(Gtk.Label(label="%s: %s" % (self.tr("stat_now"),
                                             fmt_amount(float(q.get("used_bytes", 0)), KIND)),
                           halign=Gtk.Align.START))
        area.show_all()
        resp = dialog.run()
        if resp == Gtk.ResponseType.OK:
            value = parse_amount(sp.get_value(), ["", "k", "M", "G", "T"][cb_p.get_active()],
                                 cb_k.get_active_text())
            self.app.sampler.set_quota_counter(value)
            self.app.apply_all()
            self.refresh_general()
        dialog.destroy()