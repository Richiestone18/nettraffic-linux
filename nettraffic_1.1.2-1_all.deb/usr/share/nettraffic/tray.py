#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Icono de bandeja (AyatanaAppIndicator3) dibujado dinámicamente:
estados TX+RX / solo TX / solo RX / inactivo (como el original) y, con cuota
habilitada, barra superior = % del límite usado, barra inferior = transcurso del
periodo de facturación (indicador 'quota_usage_period_lapse_indicator')."""
import os
import tempfile

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('AyatanaAppIndicator3', '0.1')
from gi.repository import AyatanaAppIndicator3 as AppIndicator
import cairo

from .core import theme_colors, hex_to_rgba, quota_period_progress, q_enabled

ICON_SIZE = 22
ACTIVITY_THRESHOLD = 1024.0   # 1 kiB/s


class TrayIcon:
    def __init__(self, app):
        self.app = app
        self.cfg = app.cfg
        self._sig = None
        self.indicator = AppIndicator.Indicator.new(
            "nettraffic", "network-transmit-receive",
            AppIndicator.IndicatorCategory.APPLICATION_STATUS)
        self.indicator.set_status(AppIndicator.IndicatorStatus.ACTIVE)
        self.icon_dir = tempfile.mkdtemp(prefix="nettraffic-tray-")
        self.icon_path = os.path.join(self.icon_dir, "icon.png")
        self.update(force=True)
        self.indicator.set_menu(self.app.menu)
        self.indicator.set_title("NetTraffic")

    def update(self, force=False):
        dl, ul = self.app.sampler.get_rates()
        quota_on = q_enabled(self.cfg)
        if quota_on:
            quota_pct = self.app.sampler.get_quota_pct()
            period_pct = quota_period_progress(self.cfg)
        else:
            quota_pct, period_pct = None, None
        rx_active = dl > ACTIVITY_THRESHOLD
        tx_active = ul > ACTIVITY_THRESHOLD
        # con cuota activa se redibuja seguido: la barra crece byte a byte
        sig = (rx_active, tx_active,
               None if quota_pct is None else round(quota_pct, 4),
               None if period_pct is None else round(period_pct, 3),
               self.cfg["plot"].get("theme"))
        if sig == self._sig and not force:
            return
        self._sig = sig
        self._render(rx_active, tx_active, quota_pct, period_pct)
        try:
            self.indicator.set_icon_full(self.icon_path, "NetTraffic")
        except Exception:
            try:
                self.indicator.set_icon(self.icon_path)
            except Exception:
                pass

    def _render(self, rx_active, tx_active, quota_pct, period_pct):
        s = ICON_SIZE
        theme = theme_colors(self.cfg)
        surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, s, s)
        cr = cairo.Context(surface)
        # fondo transparente
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.rectangle(0, 0, s, s)
        cr.fill()
        cr.set_operator(cairo.OPERATOR_OVER)

        if not rx_active and not tx_active:
            self._monitor(cr, 2, 4, 7, False, None)
            self._monitor(cr, 12, 9, 7, False, None)
        elif rx_active and tx_active:
            self._monitor(cr, 2, 4, 7, True, theme["download"])
            self._monitor(cr, 12, 9, 7, True, theme["upload"])
        elif rx_active:
            self._monitor(cr, 3, 6, 8, True, theme["download"])
        else:
            self._monitor(cr, 9, 6, 8, True, theme["upload"])

        if quota_pct is not None:
            bar_w = s - 2
            col = (theme["download"] if quota_pct < 0.8 else
                   (theme["activity"] if quota_pct < 1.0 else theme["upload"]))
            # barra superior: uso del límite
            cr.set_source_rgba(0, 0, 0, 0.55)
            cr.rectangle(1, 0, bar_w, 3)
            cr.fill()
            cr.set_source_rgba(*hex_to_rgba(col))
            cr.rectangle(1, 0, bar_w * quota_pct, 3)
            cr.fill()
            # barra inferior: transcurso del periodo
            cr.set_source_rgba(0, 0, 0, 0.55)
            cr.rectangle(1, s - 3, bar_w, 2)
            cr.fill()
            cr.set_source_rgba(*hex_to_rgba(theme["total"]))
            cr.rectangle(1, s - 3, bar_w * (period_pct or 0.0), 2)
            cr.fill()

        surface.write_to_png(self.icon_path)

    def _monitor(self, cr, x, y, size, on, color):
        """Mini-monitor estilo NetTraffic (pantalla + peana)."""
        cr.set_line_width(1.0)
        cr.set_source_rgba(0.85, 0.85, 0.85, 0.9)
        cr.rectangle(x, y, size, size * 0.72)
        cr.stroke()
        cr.move_to(x + size * 0.2, y + size * 0.78)
        cr.line_to(x + size * 0.8, y + size * 0.78)
        cr.stroke()
        if on and color:
            cr.set_source_rgba(*hex_to_rgba(color, 0.95))
            cr.rectangle(x + 1.5, y + 1.5, size - 3, size * 0.72 - 3)
            cr.fill()
        else:
            cr.set_source_rgba(0.35, 0.35, 0.35, 0.5)
            cr.rectangle(x + 1.5, y + 1.5, size - 3, size * 0.72 - 3)
            cr.fill()

    def set_menu(self, menu):
        self.indicator.set_menu(menu)

    def hide(self):
        self.indicator.set_status(AppIndicator.IndicatorStatus.PASSIVE)